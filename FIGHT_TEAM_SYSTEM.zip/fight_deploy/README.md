# ᶜʰᵉᶠ FIGHT TEAM² — نظام إدارة البوتات

## 🗂️ هيكل الملفات

```
fight_deploy/
├── server.py          ← السيرفر الرئيسي (Flask)
├── main.py            ← البوت الرئيسي
├── run.py             ← مراقب البوت
├── static/
│   └── index.html    ← لوحة التحكم
├── AlliFF.txt         ← بيانات البوتات (uid: password)
├── requirements.txt   ← المكتبات المطلوبة
├── Dockerfile         ← للنشر عبر Docker
├── start.sh           ← سكريبت التشغيل السريع
└── ... باقي ملفات البوت
```

---

## 🚀 طريقة النشر على VPS

### الطريقة 1: مباشرة (بدون Docker)

```bash
# 1. ارفع الملفات للسيرفر
scp -r fight_deploy/ root@YOUR_VPS_IP:/root/

# 2. اتصل بالسيرفر
ssh root@YOUR_VPS_IP

# 3. ادخل المجلد وشغّل
cd /root/fight_deploy
chmod +x start.sh
./start.sh
```

### الطريقة 2: Docker

```bash
# بناء وتشغيل
docker build -t fight-team .
docker run -d -p 3002:3002 --name fight-bot fight-team

# عرض اللوگ
docker logs -f fight-bot

# إيقاف
docker stop fight-bot
```

### الطريقة 3: تشغيل دائم (systemd)

```bash
# أنشئ ملف الخدمة
cat > /etc/systemd/system/fight-team.service << EOF
[Unit]
Description=Chef FIGHT TEAM Bot
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=/root/fight_deploy
ExecStart=/usr/bin/python3 server.py
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
EOF

# تفعيل وتشغيل
systemctl daemon-reload
systemctl enable fight-team
systemctl start fight-team

# عرض الحالة
systemctl status fight-team
```

---

## 🌐 الوصول للوحة التحكم

بعد التشغيل افتح في المتصفح:

```
http://YOUR_VPS_IP:3002
```

---

## ⚙️ إضافة بوت جديد

### عبر اللوحة:
- اضغط ➕ ثم أدخل الأيدي وكلمة المرور

### يدوياً في AlliFF.txt:
```json
{
  "3836675675": "YOUR_PASSWORD_HERE",
  "1234567890": "ANOTHER_PASSWORD"
}
```

---

## 🔌 API Endpoints

| Method | URL | الوظيفة |
|--------|-----|---------|
| GET | `/api/status` | حالة البوت + قائمة الحسابات |
| POST | `/api/start` | تشغيل البوت |
| POST | `/api/stop` | إيقاف البوت |
| POST | `/api/restart` | إعادة تشغيل البوت |
| GET | `/api/logs` | آخر 200 سطر من اللوگ |
| GET | `/api/bots` | قائمة البوتات |
| POST | `/api/bots` | إضافة بوت `{uid, password}` |
| DELETE | `/api/bots/<uid>` | حذف بوت |
| PUT | `/api/bots/<uid>` | تعديل بوت |

---

## 📋 أوامر البوت داخل اللعبة

| الأمر | الوظيفة |
|-------|---------|
| `/help` | قائمة الأوامر |
| `/info <id>` | معلومات اللاعب |
| `/status <id>` | حالة اللاعب |
| `/inv <id>` | دعوة للسكواد |
| `/3` `/5` `/6` | تحويل نوع الفريق |
| `/spam <id>` | سبام طلبات صداقة |
| `/room <id>` | سبام الروم |
| `/visit <id>` | إرسال زيارات |
| `/check <id>` | فحص الباند |
| `/lag <code>` | هجوم لاج |
| `/attack <code>` | هجوم مزدوج |
| `/ghost <code> <n>` | أشباح |
| `/emote <id> <رقصة>` | إرسال رقصة |
| `/ai <سؤال>` | ذكاء اصطناعي |
| `/solo` | خروج من السكواد |
| `/come <code>` | انضمام للفريق |
| `/bio <id>` | عرض البايو |
| `/rest` | إراحة البوت |

---

**Telegram:** @fight_90
