# -*- coding: utf-8 -*-
"""
ff_sender.py — إرسال طلبات الصداقة لـ Free Fire
يستخدم combined_accounts_clean.json (727 حساب)
مبني على app.py من ملف FIGHT³
"""

import requests, json, os, random, time, threading
import urllib3
urllib3.disable_warnings()

try:
    from Crypto.Cipher import AES
    from Crypto.Util.Padding import pad, unpad
except ImportError:
    from Cryptodome.Cipher import AES
    from Cryptodome.Util.Padding import pad, unpad

BASE_DIR      = os.path.dirname(os.path.abspath(__file__))
ACCOUNTS_FILE = os.path.join(BASE_DIR, 'combined_accounts_clean.json')
JWT_CACHE     = os.path.join(BASE_DIR, 'ff_jwt_cache.json')

# ── AES Keys (from app.py) ────────────────────────────────────────
KEY = bytes([89, 103, 38, 116, 99, 37, 68, 69, 117, 104, 54, 37, 90, 99, 94, 56])
IV  = bytes([54, 111, 121, 90, 68, 114, 50, 50, 69, 51, 121, 99, 104, 106, 77, 37])

# ── Server URLs by region (from ServerURL.txt) ────────────────────
REGION_URLS = {
    "IND": "https://client.ind.freefiremobile.com",
    "BR":  "https://client.us.freefiremobile.com",
    "US":  "https://client.us.freefiremobile.com",
    "SAC": "https://client.us.freefiremobile.com",
    "NA":  "https://client.us.freefiremobile.com",
    "EU":  "https://clientbp.ggblueshark.com",
    "ME":  "https://clientbp.ggblueshark.com",
    "ID":  "https://clientbp.ggblueshark.com",
    "TH":  "https://clientbp.ggblueshark.com",
    "VN":  "https://clientbp.ggblueshark.com",
    "SG":  "https://clientbp.ggwhitehawk.com",
    "BD":  "https://clientbp.ggwhitehawk.com",
    "PK":  "https://clientbp.ggblueshark.com",
    "MY":  "https://clientbp.ggblueshark.com",
    "PH":  "https://clientbp.ggblueshark.com",
    "RU":  "https://clientbp.ggblueshark.com",
}
DEFAULT_URL = "https://clientbp.ggblueshark.com"

def _get_url(region: str) -> str:
    return REGION_URLS.get(region.upper(), DEFAULT_URL)

# ── Encryption (from app.py) ──────────────────────────────────────
def _encrypt(data: bytes) -> bytes:
    cipher = AES.new(KEY, AES.MODE_CBC, IV)
    return cipher.encrypt(pad(data, AES.block_size))

def _decrypt(data: bytes) -> bytes:
    cipher = AES.new(KEY, AES.MODE_CBC, IV)
    return unpad(cipher.decrypt(data), AES.block_size)

def encrypt_api(hex_str: str) -> str:
    return _encrypt(bytes.fromhex(hex_str)).hex()

# ── Token generation ──────────────────────────────────────────────
OLD_TOKEN = "ff90c07eb9815af30a43b4a9f6019516e0e4c703b44092516d0defa4cef51f2a"
OLD_OID   = "996a629dbcdb3964be6b6978f5d814db"
BASE_PROTO = '1a13323032352d30372d33302031313a30323a3531220966726565206669726528013a07312e3131342e32422c416e64726f6964204f5320372e312e32202f204150492d323320284e32473438382f373030323530323234294a0848616e6468656c645207416e64726f69645a045749464960c00c68840772033332307a1f41524d7637205646507633204e454f4e20564d48207c2032343635207c203480019a1b8a010f416472656e6f2028544d292036343092010d4f70656e474c20455320332e319a012b476f6f676c657c31663361643662372d636562342d343934622d383730622d623164616364373230393131a2010c3139372e312e31322e313335aa0102656eb201203939366136323964626364623339363462653662363937386635643831346462ba010134c2010848616e6468656c64ca011073616d73756e6720534d2d473935354eea014066663930633037656239383135616633306134336234613966363031393531366530653463373033623434303932353136643064656661346365663531663261f00101ca0207416e64726f6964d2020457494649ca03203734323862323533646566633136343031386336303461316562626665626466e003daa907e803899b07f003bf0ff803ae088004999b078804daa9079004999b079804daa907c80403d204262f646174612f6170702f636f6d2e6474732e667265656669726574682d312f6c69622f61726de00401ea044832303837663631633139663537663261663465376665666630623234643964397c2f646174612f6170702f636f6d2e6474732e667265656669726574682d312f626173652e61704bf00403f804018a050233329a050a32303139313138363933a80503b205094f70656e474c455332b805ff7fc00504e005dac901ea0507616e64726f6964f2055c4b71734854394748625876574c6668437950416c52526873626d43676542557562555551317375746d525536634e30524f3751453141486e496474385963784d614c575437636d4851322b7374745279377830663935542b6456593d8806019006019a060134a2060134b2061e40001147550d0c074f530b4d5c584d57416657545a065f2a091d6a0d5033'

def _garena_login(uid: str, password: str):
    """تسجيل دخول Garena → (access_token, open_id)"""
    try:
        r = requests.post(
            "https://100067.connect.garena.com/oauth/guest/token/grant",
            headers={
                "User-Agent": "GarenaMSDK/4.0.19P4(G011A ;Android 9;en;US;)",
                "Content-Type": "application/x-www-form-urlencoded",
            },
            data={"uid": str(uid), "password": password,
                  "response_type": "token", "client_type": "2",
                  "client_secret": "", "client_id": "100067"},
            timeout=12, verify=False
        )
        d = r.json()
        return d.get("access_token"), d.get("open_id")
    except Exception as e:
        print(f"garena_login error [{uid}]: {e}")
        return None, None

def _make_jwt(access_token: str, open_id: str) -> str:
    """حوّل access_token إلى JWT"""
    try:
        data = bytes.fromhex(BASE_PROTO)
        data = data.replace(OLD_OID.encode(), open_id.encode())
        data = data.replace(OLD_TOKEN.encode(), access_token.encode())
        payload = _encrypt(bytes.fromhex(encrypt_api(data.hex())))
        # encrypt_api already returns hex, re-encrypt is wrong
        # correct: encrypt data.hex() once
        enc_hex = encrypt_api(data.hex())
        payload = bytes.fromhex(enc_hex)
        r = requests.post(
            "https://loginbp.ggblueshark.com/MajorLogin",
            headers={
                "Host": "loginbp.ggblueshark.com",
                "X-Unity-Version": "2018.4.11f1",
                "Authorization": "Bearer",
                "ReleaseVersion": "OB52",
                "X-GA": "v1 1",
                "Content-Type": "application/x-www-form-urlencoded",
                "User-Agent": "Free%20Fire/2019118692 CFNetwork/3826.500.111.2.2 Darwin/24.4.0",
                "Connection": "keep-alive",
            },
            data=payload, timeout=12, verify=False
        )
        if r.status_code == 200 and len(r.text) > 10:
            marker = "eyJhbGciOiJIUzI1NiIsInN2ciI6IjEiLCJ0eXAiOiJKV1QifQ"
            idx = r.text.find(marker)
            if idx != -1:
                jwt = r.text[idx:-1]
                dot2 = jwt.find(".", jwt.find(".") + 1)
                return jwt[:dot2 + 44]
        return None
    except Exception as e:
        print(f"_make_jwt error: {e}")
        return None

# ── JWT cache ─────────────────────────────────────────────────────
_cache_lock = threading.Lock()

def _load_cache() -> dict:
    try:
        with open(JWT_CACHE) as f:
            return json.load(f)
    except:
        return {}

def _save_cache(data: dict):
    try:
        with open(JWT_CACHE, 'w') as f:
            json.dump(data, f)
    except:
        pass

def _get_jwt(uid: str, password: str) -> str:
    """JWT مع كاش 45 دقيقة"""
    with _cache_lock:
        cache = _load_cache()
        entry = cache.get(str(uid), {})
        if entry.get('jwt') and time.time() - entry.get('ts', 0) < 2700:
            return entry['jwt']

    access_token, open_id = _garena_login(uid, password)
    if not access_token:
        return None

    jwt = _make_jwt(access_token, open_id)
    if jwt:
        with _cache_lock:
            cache = _load_cache()
            cache[str(uid)] = {'jwt': jwt, 'ts': time.time()}
            _save_cache(cache)

    return jwt

# ── Load accounts ─────────────────────────────────────────────────
def _load_accounts() -> list:
    try:
        with open(ACCOUNTS_FILE) as f:
            return json.load(f)
    except Exception as e:
        print(f"load_accounts error: {e}")
        return []

# ── Core send function (from app.py) ─────────────────────────────
def _send_one(addee_uid: int, jwt_token: str, region: str = "ME") -> dict:
    """
    إرسال طلب صداقة واحد — نفس منطق app.py
    يستخدم AddStarFriend protobuf
    """
    try:
        import AddStarFriend_pb2
        req = AddStarFriend_pb2.CSAddStarFriendReq()
        req.addee = int(addee_uid)
        serialized = req.SerializeToString()
        encrypted  = _encrypt(serialized)
        base_url   = _get_url(region)
        url        = f"{base_url}/AddStarFriend"
        headers = {
            "X-GA":           "v1 1",
            "Content-Type":   "application/octet-stream",
            "Authorization":  f"Bearer {jwt_token}",
            "ReleaseVersion": "OB52",
            "User-Agent":     "UnityPlayer/2022.3.47f1 (UnityWebRequest/1.0, libcurl/8.5.0-DEV)"
        }
        r = requests.post(url, data=encrypted, headers=headers, verify=False, timeout=12)
        if r.status_code == 200:
            return {'ok': True, 'msg': '✅ تم إرسال طلب الصداقة بنجاح!'}
        elif r.status_code == 401:
            return {'ok': False, 'msg': '🔑 توكن منتهي', 'expired': True}
        else:
            return {'ok': False, 'msg': f'❌ كود {r.status_code}: {r.text[:60]}'}
    except Exception as e:
        return {'ok': False, 'msg': f'❌ {str(e)[:60]}'}

# ── Bulk send ─────────────────────────────────────────────────────
def send_bulk(player_id: str, count: int = 1) -> dict:
    """
    يبعث count طلبات صداقة لـ player_id
    يختار حسابات عشوائية من combined_accounts_clean.json
    """
    accounts = _load_accounts()
    if not accounts:
        return {'ok': False, 'msg': '❌ combined_accounts_clean.json فارغ أو غير موجود', 'success': 0}

    selected = random.sample(accounts, min(count, len(accounts)))
    success  = 0
    errors   = []

    for acc in selected:
        uid      = str(acc['uid'])
        password = acc['password']
        region   = acc.get('region', 'ME')

        # Get JWT
        jwt = _get_jwt(uid, password)
        if not jwt:
            errors.append(f"⚠️ فشل JWT للحساب {uid}")
            continue

        # Send
        time.sleep(random.uniform(0.2, 0.6))
        r = _send_one(player_id, jwt, region)

        if r['ok']:
            success += 1
        elif r.get('expired'):
            # مسح الكاش وإعادة المحاولة
            with _cache_lock:
                cache = _load_cache()
                cache.pop(uid, None)
                _save_cache(cache)
            jwt2 = _get_jwt(uid, password)
            if jwt2:
                r2 = _send_one(player_id, jwt2, region)
                if r2['ok']:
                    success += 1
                else:
                    errors.append(r2['msg'])
        else:
            errors.append(r['msg'])

    parts = [f"🤝 طلبات صداقة: {success}/{len(selected)} ✅"]
    if errors:
        # اعرض فقط أول خطأ مختلف
        unique_errors = list(dict.fromkeys(errors))[:2]
        parts += unique_errors

    return {'ok': success > 0, 'msg': '<br>'.join(parts), 'success': success}

# ── Token status for dashboard ────────────────────────────────────
def get_token_status() -> dict:
    cache    = _load_cache()
    now      = time.time()
    valid    = sum(1 for v in cache.values() if now - v.get('ts', 0) < 2700)
    accounts = _load_accounts()
    return {
        'valid':      valid,
        'cached':     len(cache),
        'accs_count': len(accounts),
        'uid':        f"{valid}/{len(accounts)} حساب نشط"
    }
