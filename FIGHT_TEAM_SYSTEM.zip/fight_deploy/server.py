# -*- coding: utf-8 -*-
"""
ᶜʰᵉᶠ FIGHT TEAM² — Unified Server
يشغّل لوحة التحكم + بوت Free Fire + بوت Telegram
"""

import os, sys, json, subprocess, threading, time, secrets
from flask import Flask, request, jsonify, send_from_directory, session
from datetime import datetime

BASE_DIR   = os.path.dirname(os.path.abspath(__file__))
STATIC_DIR = os.path.join(BASE_DIR, 'static')
FF_BOT     = os.path.join(BASE_DIR, 'main.py')
TG_BOT     = os.path.join(BASE_DIR, 'tg_bot.py')
BOTS_FILE  = os.path.join(BASE_DIR, 'AlliFF.txt')
ACCS_FILE  = os.path.join(BASE_DIR, 'accs.json')
USERS_FILE = os.path.join(BASE_DIR, 'panel_users.json')
CODES_FILE = os.path.join(BASE_DIR, 'invite_codes.json')
TG_BOT     = os.path.join(BASE_DIR, 'groups2.json')
def _load_codes():
    try:
        with open(CODES_FILE) as f: return json.load(f)
    except: return {}

def _save_codes(data):
    with open(CODES_FILE, 'w') as f: json.dump(data, f)

def _validate_code(code: str):
    """تحقق من صحة الكود — يرجع (valid, type, expires)"""
    codes = _load_codes()
    c = codes.get(code.upper())
    if not c:
        return False, None, None
    if c.get('used'):
        return False, 'used', None
    if time.time() > c.get('expires', 0):
        return False, 'expired', None
    return True, c['type'], c['expires']

def _use_code(code: str, username: str):
    codes = _load_codes()
    c = codes.get(code.upper())
    if not c: return False
    c['used']    = True
    c['used_by'] = username
    c['used_at'] = time.time()
    _save_codes(codes)
    return True


app = Flask(__name__, static_folder=STATIC_DIR, static_url_path='/static')
app.secret_key = secrets.token_hex(32)

# ─── Panel users ─────────────────────────────────────────────────
DEFAULT_USERS = {
    "admin": {
        "password": "fight2580",
        "role": "admin",
        "label": "ᶜʰᵉᶠ FIGHT",
        "bots": []
    }
}

def _load_panel_users():
    if os.path.exists(USERS_FILE):
        try:
            with open(USERS_FILE) as f:
                return json.load(f)
        except Exception:
            pass
    _save_panel_users(DEFAULT_USERS)
    return DEFAULT_USERS

def _save_panel_users(data):
    with open(USERS_FILE, 'w') as f:
        json.dump(data, f, indent=2, ensure_ascii=False)

def _get_session_user():
    u = session.get('username')
    if not u: return None
    return _load_panel_users().get(u)

def _require_login():
    if not _get_session_user():
        return jsonify({'ok': False, 'msg': 'غير مسجّل دخول', 'code': 401}), 401

def _require_admin():
    err = _require_login()
    if err: return err
    u = _get_session_user()
    if u['role'] != 'admin':
        return jsonify({'ok': False, 'msg': 'صلاحية أدمن مطلوبة', 'code': 403}), 403

# ─── Bot data ────────────────────────────────────────────────────
def _load_bots():
    try:
        with open(BOTS_FILE) as f: return json.load(f)
    except: return {}

def _save_bots(data):
    with open(BOTS_FILE, 'w') as f: json.dump(data, f, indent=2)

def _load_accs():
    try:
        with open(ACCS_FILE) as f: return json.load(f)
    except: return {}

# ─── Process management ──────────────────────────────────────────
# FF bots: uid -> process
ff_processes = {}
# TG bot: single process
tg_process   = None
bot_logs     = {}     # uid -> [lines]
tg_logs      = []     # telegram bot logs
global_logs  = []
bot_lock     = threading.Lock()
MAX_LOGS     = 300

def _log(uid, line):
    ts    = datetime.now().strftime('%H:%M:%S')
    entry = f"[{ts}][{uid}] {line.rstrip()}"
    with bot_lock:
        if uid not in bot_logs:
            bot_logs[uid] = []
        bot_logs[uid].append(entry)
        if len(bot_logs[uid]) > MAX_LOGS:
            bot_logs[uid].pop(0)
        global_logs.append(entry)
        if len(global_logs) > MAX_LOGS * 5:
            global_logs.pop(0)

def _log_tg(line):
    ts    = datetime.now().strftime('%H:%M:%S')
    entry = f"[{ts}][TG] {line.rstrip()}"
    with bot_lock:
        tg_logs.append(entry)
        if len(tg_logs) > MAX_LOGS:
            tg_logs.pop(0)
        global_logs.append(entry)
        if len(global_logs) > MAX_LOGS * 5:
            global_logs.pop(0)

def _read_ff(uid, proc):
    for line in iter(proc.stdout.readline, ''):
        _log(uid, line)
    proc.stdout.close()

def _read_tg(proc):
    for line in iter(proc.stdout.readline, ''):
        _log_tg(line)
    proc.stdout.close()

# ── FF Bot ──
def _start_ff(uid):
    with bot_lock:
        p = ff_processes.get(uid)
        if p and p.poll() is None: return
    _log(uid, f"▶ تشغيل FF بوت {uid}...")
    try:
        env = os.environ.copy()
        env['FF_UID'] = uid
        proc = subprocess.Popen(
            [sys.executable, FF_BOT],
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
            text=True, bufsize=1, encoding='utf-8',
            cwd=BASE_DIR, env=env
        )
        with bot_lock:
            ff_processes[uid] = proc
        threading.Thread(target=_read_ff, args=(uid, proc), daemon=True).start()
        _log(uid, f"✅ FF بوت {uid} يعمل — PID {proc.pid}")
    except Exception as e:
        _log(uid, f"❌ خطأ FF: {e}")

def _stop_ff(uid):
    with bot_lock:
        proc = ff_processes.get(uid)
    if proc and proc.poll() is None:
        _log(uid, f"⏹ إيقاف FF بوت {uid}")
        proc.terminate()
        try: proc.wait(timeout=5)
        except: proc.kill()
    with bot_lock:
        ff_processes.pop(uid, None)

# ── TG Bot ──
def _start_tg():
    global tg_process
    with bot_lock:
        if tg_process and tg_process.poll() is None: return
    _log_tg("▶ تشغيل بوت Telegram...")
    try:
        proc = subprocess.Popen(
            [sys.executable, TG_BOT],
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
            text=True, bufsize=1, encoding='utf-8',
            cwd=BASE_DIR
        )
        with bot_lock:
            tg_process = proc
        threading.Thread(target=_read_tg, args=(proc,), daemon=True).start()
        _log_tg(f"✅ بوت Telegram يعمل — PID {proc.pid}")
    except Exception as e:
        _log_tg(f"❌ خطأ TG: {e}")

def _stop_tg():
    global tg_process
    with bot_lock:
        proc = tg_process
    if proc and proc.poll() is None:
        _log_tg("⏹ إيقاف بوت Telegram")
        proc.terminate()
        try: proc.wait(timeout=5)
        except: proc.kill()
    with bot_lock:
        tg_process = None

def _start_all():
    time.sleep(2)
    for uid in _load_bots():
        _start_ff(uid)
    _start_tg()

threading.Thread(target=_start_all, daemon=True).start()

# ─── Routes ──────────────────────────────────────────────────────
@app.route('/')
def index():
    return send_from_directory(STATIC_DIR, 'index.html')

@app.route('/<path:f>')
def static_f(f):
    if f.startswith('api/'): return jsonify({'ok': False}), 404
    return send_from_directory(STATIC_DIR, f)

# ─── AUTH ────────────────────────────────────────────────────────
@app.route('/api/login', methods=['POST'])
def api_login():
    data = request.json or {}
    u    = str(data.get('username', '')).strip()
    p    = str(data.get('password', '')).strip()
    code = str(data.get('code', '')).strip()
    users = _load_panel_users()
    user  = users.get(u)
    if not user or user['password'] != p:
        return jsonify({'ok': False, 'msg': '❌ اسم المستخدم أو كلمة المرور خاطئة'}), 401
    # Check invite code for non-admin users
    if user.get('role') != 'admin':
        if not code:
            return jsonify({'ok': False, 'msg': '🔑 أدخل كود الدعوة للدخول', 'need_code': True}), 401
        valid, ctype, cexp = _validate_code(code)
        if not valid:
            if ctype == 'used':
                return jsonify({'ok': False, 'msg': '❌ هذا الكود مستخدم مسبقاً'}), 401
            elif ctype == 'expired':
                return jsonify({'ok': False, 'msg': '❌ هذا الكود منتهي الصلاحية'}), 401
            return jsonify({'ok': False, 'msg': '❌ كود الدعوة غير صحيح'}), 401
        _use_code(code, u)
    session['username'] = u
    session.permanent   = True
    return jsonify({'ok': True, 'role': user['role'], 'label': user.get('label', u), 'bots': user.get('bots', [])})

@app.route('/api/logout', methods=['POST'])
def api_logout():
    session.clear()
    return jsonify({'ok': True})

@app.route('/api/me')
def api_me():
    u = _get_session_user()
    if not u: return jsonify({'ok': False, 'code': 401}), 401
    un = session.get('username')
    return jsonify({'ok': True, 'username': un, 'role': u['role'], 'label': u.get('label', un), 'bots': u.get('bots', [])})

# ─── STATUS ──────────────────────────────────────────────────────
@app.route('/api/status')
def api_status():
    err = _require_login()
    if err: return err
    u        = _get_session_user()
    all_bots = _load_bots()
    visible  = all_bots if u['role'] == 'admin' or not u.get('bots') else {uid: pwd for uid, pwd in all_bots.items() if uid in u['bots']}

    bots_status = {}
    for uid in visible:
        proc = ff_processes.get(uid)
        bots_status[uid] = {'running': proc is not None and proc.poll() is None}

    tg_running = tg_process is not None and tg_process.poll() is None

    return jsonify({
        'ok': True,
        'role': u['role'],
        'bots': visible,
        'bots_status': bots_status,
        'bot_count': len(visible),
        'tg_running': tg_running,
        'tg_pid': tg_process.pid if tg_running else None
    })

# ─── FF BOT CONTROL ──────────────────────────────────────────────
def _can_control(uid):
    u = _get_session_user()
    if not u: return False
    return u['role'] == 'admin' or uid in u.get('bots', [])

@app.route('/api/start/<uid>', methods=['POST'])
def api_ff_start(uid):
    err = _require_login()
    if err: return err
    if not _can_control(uid): return jsonify({'ok': False, 'msg': '❌ لا صلاحية'}), 403
    threading.Thread(target=_start_ff, args=(uid,), daemon=True).start()
    return jsonify({'ok': True, 'msg': f'▶ تشغيل FF بوت {uid}'})

@app.route('/api/stop/<uid>', methods=['POST'])
def api_ff_stop(uid):
    err = _require_login()
    if err: return err
    if not _can_control(uid): return jsonify({'ok': False, 'msg': '❌ لا صلاحية'}), 403
    threading.Thread(target=_stop_ff, args=(uid,), daemon=True).start()
    return jsonify({'ok': True, 'msg': f'⏹ إيقاف FF بوت {uid}'})

@app.route('/api/restart/<uid>', methods=['POST'])
def api_ff_restart(uid):
    err = _require_login()
    if err: return err
    if not _can_control(uid): return jsonify({'ok': False, 'msg': '❌ لا صلاحية'}), 403
    def do():
        _stop_ff(uid); time.sleep(1); _start_ff(uid)
    threading.Thread(target=do, daemon=True).start()
    return jsonify({'ok': True, 'msg': f'🔄 إعادة FF بوت {uid}'})

# ─── TG BOT CONTROL ──────────────────────────────────────────────
@app.route('/api/tg/start', methods=['POST'])
def api_tg_start():
    err = _require_admin()
    if err: return err
    threading.Thread(target=_start_tg, daemon=True).start()
    return jsonify({'ok': True, 'msg': '▶ تشغيل بوت Telegram'})

@app.route('/api/tg/stop', methods=['POST'])
def api_tg_stop():
    err = _require_admin()
    if err: return err
    threading.Thread(target=_stop_tg, daemon=True).start()
    return jsonify({'ok': True, 'msg': '⏹ إيقاف بوت Telegram'})

@app.route('/api/tg/restart', methods=['POST'])
def api_tg_restart():
    err = _require_admin()
    if err: return err
    def do():
        _stop_tg(); time.sleep(1); _start_tg()
    threading.Thread(target=do, daemon=True).start()
    return jsonify({'ok': True, 'msg': '🔄 إعادة بوت Telegram'})

# ─── LOGS ────────────────────────────────────────────────────────
@app.route('/api/logs')
def api_logs():
    err = _require_login()
    if err: return err
    u       = _get_session_user()
    bot_t   = request.args.get('bot', 'ff')  # ff | tg | all
    uid_req = request.args.get('uid')

    if u['role'] == 'admin':
        if bot_t == 'tg':
            logs = list(tg_logs)
        elif uid_req:
            logs = list(bot_logs.get(uid_req, []))
        else:
            logs = list(global_logs[-MAX_LOGS:])
    else:
        allowed = u.get('bots', [])
        logs = []
        for uid in allowed:
            logs += bot_logs.get(uid, [])
        logs.sort()
        logs = logs[-MAX_LOGS:]

    return jsonify({'logs': logs})

# ─── TG BOT DATA (stats from json files) ─────────────────────────
@app.route('/api/tg/stats')
def api_tg_stats():
    err = _require_login()
    if err: return err
    try:
        with open(os.path.join(BASE_DIR, 'users2.json')) as f:
            users = json.load(f)
        with open(os.path.join(BASE_DIR, 'groups2.json')) as f:
            groups = json.load(f)
        total_adds = sum(
            u.get('adds_today', 0) if isinstance(u, dict) else 0
            for u in users.values()
        ) if isinstance(users, dict) else 0
        return jsonify({'ok': True, 'users': len(users) if isinstance(users, dict) else 0, 'groups': len(groups), 'adds_today': total_adds})
    except:
        return jsonify({'ok': True, 'users': 0, 'groups': 0, 'adds_today': 0})

# ─── BOTS CRUD ───────────────────────────────────────────────────
@app.route('/api/bots', methods=['POST'])
def api_bots_add():
    err = _require_admin()
    if err: return err
    data      = request.json or {}
    uid       = str(data.get('uid', '')).strip()
    pwd       = str(data.get('password', '')).strip()
    assign_to = str(data.get('assign_to', '')).strip()
    if not uid or not pwd: return jsonify({'ok': False, 'msg': 'أيدي وكلمة المرور مطلوبان'}), 400
    bots = _load_bots()
    if uid in bots: return jsonify({'ok': False, 'msg': 'موجود بالفعل'}), 409
    bots[uid] = pwd
    _save_bots(bots)
    if assign_to:
        users = _load_panel_users()
        if assign_to in users:
            users[assign_to].setdefault('bots', [])
            if uid not in users[assign_to]['bots']:
                users[assign_to]['bots'].append(uid)
            _save_panel_users(users)
    threading.Thread(target=_start_ff, args=(uid,), daemon=True).start()
    return jsonify({'ok': True, 'msg': f'✅ تمت إضافة البوت {uid}'})

@app.route('/api/bots/<uid>', methods=['DELETE'])
def api_bots_del(uid):
    err = _require_login()
    if err: return err
    if not _can_control(uid): return jsonify({'ok': False, 'msg': '❌ لا صلاحية'}), 403
    _stop_ff(uid)
    bots = _load_bots()
    if uid not in bots: return jsonify({'ok': False, 'msg': 'غير موجود'}), 404
    del bots[uid]
    _save_bots(bots)
    return jsonify({'ok': True, 'msg': f'🗑️ تم حذف {uid}'})

@app.route('/api/bots/<uid>', methods=['PUT'])
def api_bots_upd(uid):
    err = _require_login()
    if err: return err
    if not _can_control(uid): return jsonify({'ok': False, 'msg': '❌ لا صلاحية'}), 403
    data = request.json or {}
    bots = _load_bots()
    if uid not in bots: return jsonify({'ok': False, 'msg': 'غير موجود'}), 404
    new_uid = str(data.get('new_uid', uid)).strip()
    new_pwd = str(data.get('password', bots[uid])).strip()
    del bots[uid]; bots[new_uid] = new_pwd
    _save_bots(bots)
    return jsonify({'ok': True, 'msg': '✅ تم الحفظ'})

# ─── PANEL USERS ─────────────────────────────────────────────────
@app.route('/api/users', methods=['GET'])
def api_users_get():
    err = _require_admin()
    if err: return err
    users = _load_panel_users()
    safe  = {u: {k: v for k, v in d.items() if k != 'password'} for u, d in users.items()}
    return jsonify({'ok': True, 'users': safe})

@app.route('/api/users', methods=['POST'])
def api_users_add():
    err = _require_admin()
    if err: return err
    data  = request.json or {}
    uname = str(data.get('username', '')).strip()
    pwd   = str(data.get('password', '')).strip()
    label = str(data.get('label', uname)).strip()
    bots  = data.get('bots', [])
    if not uname or not pwd: return jsonify({'ok': False, 'msg': 'بيانات ناقصة'}), 400
    users = _load_panel_users()
    if uname in users: return jsonify({'ok': False, 'msg': 'موجود بالفعل'}), 409
    users[uname] = {'password': pwd, 'role': 'user', 'label': label, 'bots': bots}
    _save_panel_users(users)
    return jsonify({'ok': True, 'msg': f'✅ تمت إضافة {uname}'})

@app.route('/api/users/<uname>', methods=['DELETE'])
def api_users_del(uname):
    err = _require_admin()
    if err: return err
    if uname == 'admin': return jsonify({'ok': False, 'msg': 'لا يمكن حذف الأدمن'}), 400
    users = _load_panel_users()
    if uname not in users: return jsonify({'ok': False, 'msg': 'غير موجود'}), 404
    del users[uname]; _save_panel_users(users)
    return jsonify({'ok': True, 'msg': f'🗑️ تم حذف {uname}'})

@app.route('/api/users/<uname>', methods=['PUT'])
def api_users_upd(uname):
    err = _require_admin()
    if err: return err
    data  = request.json or {}
    users = _load_panel_users()
    if uname not in users: return jsonify({'ok': False, 'msg': 'غير موجود'}), 404
    if data.get('password'): users[uname]['password'] = data['password']
    if 'bots'  in data: users[uname]['bots']  = data['bots']
    if 'label' in data: users[uname]['label']  = data['label']
    _save_panel_users(users)
    return jsonify({'ok': True, 'msg': '✅ تم الحفظ'})

# ─── SEND ────────────────────────────────────────────────────────
@app.route('/api/send', methods=['POST'])
def api_send():
    err = _require_login()
    if err: return err

    data   = request.json or {}
    uid    = str(data.get('uid', '')).strip()
    stype  = str(data.get('type', 'friend'))
    count  = min(int(data.get('count', 1)), 10)

    if not uid or not uid.isdigit():
        return jsonify({'ok': False, 'msg': 'أيدي اللاعب غير صحيح'}), 400

    results = []
    ok      = False

    # ── طلب صداقة FF (الحقيقي من main.py) ──
    if stype in ('friend', 'both'):
        try:
            from ff_sender import send_bulk
            r = send_bulk(uid, count)
            results.append(r['msg'])
            ok = ok or r['ok']
        except Exception as e:
            results.append(f'❌ خطأ FF sender: {str(e)[:60]}')

    # ── زيارة ملف ──
    if stype in ('visit', 'both'):
        try:
            import requests as req, urllib3
            urllib3.disable_warnings()
            rv = req.get(f"http://212.227.65.132:14689/visit?uid={uid}", timeout=10, verify=False)
            if rv.status_code == 200:
                vd = rv.json()
                results.append(f"👁️ زيارة: {vd.get('SuccessfulVisits','?')} ✅")
                ok = True
            else:
                results.append(f"👁️ زيارة: كود {rv.status_code}")
        except Exception as e:
            results.append(f"👁️ خطأ: {str(e)[:40]}")

    results.append("🛡️ Anti-Detect مفعّل")
    _log('send', f"📤 ({stype}×{count}) → {uid}")
    return jsonify({'ok': ok, 'msg': '<br>'.join(results)})

@app.route('/api/refresh_token', methods=['POST'])
def api_refresh_token():
    """مسح كاش التوكنات"""
    err = _require_admin()
    if err: return err
    try:
        from ff_sender import JWT_CACHE
        import os
        if os.path.exists(JWT_CACHE):
            os.remove(JWT_CACHE)
        return jsonify({'ok': True, 'msg': '✅ تم مسح الكاش — سيتجدد التوكن تلقائياً عند الإرسال'})
    except Exception as e:
        return jsonify({'ok': False, 'msg': f'❌ خطأ: {str(e)[:60]}'})

@app.route('/api/token_status')
def api_token_status():
    """حالة التوكن"""
    err = _require_login()
    if err: return err
    try:
        from ff_sender import get_token_status
        s = get_token_status()
        valid = s['valid'] > 0
        return jsonify({
            'ok': True,
            'valid': valid,
            'cached': s['cached'],
            'valid_count': s['valid'],
            'accs_count': s['accs_count'],
            'uid': f"{s['valid']}/{s['accs_count']} توكن نشط"
        })
    except Exception as e:
        return jsonify({'ok': False, 'msg': str(e)})


# ─── INVITE CODES ────────────────────────────────────────────────
@app.route('/api/codes/stats')
def api_codes_stats():
    err = _require_admin()
    if err: return err
    codes = _load_codes()
    now   = time.time()
    stats = {
        'total':        len(codes),
        'daily_total':  sum(1 for c in codes.values() if c['type']=='daily'),
        'weekly_total':  sum(1 for c in codes.values() if c['type']=='weekly'),
        'monthly_total': sum(1 for c in codes.values() if c['type']=='monthly'),
        'used':         sum(1 for c in codes.values() if c.get('used')),
        'available':    sum(1 for c in codes.values() if not c.get('used') and now < c.get('expires',0)),
        'expired':      sum(1 for c in codes.values() if not c.get('used') and now > c.get('expires',0)),
    }
    # Sample unused codes
    daily_sample  = [k for k,v in codes.items() if v['type']=='daily'  and not v.get('used') and now < v.get('expires',0)][:20]
    weekly_sample = [k for k,v in codes.items() if v['type']=='weekly' and not v.get('used') and now < v.get('expires',0)][:10]
    monthly_sample = [k for k,v in codes.items() if v['type']=='monthly' and not v.get('used') and now < v.get('expires',0)][:10]
    return jsonify({'ok': True, 'stats': stats, 'daily_sample': daily_sample, 'weekly_sample': weekly_sample, 'monthly_sample': monthly_sample})

@app.route('/api/codes/generate', methods=['POST'])
def api_codes_generate():
    err = _require_admin()
    if err: return err
    import secrets as sec
    data    = request.json or {}
    ctype   = str(data.get('type', 'daily'))
    count   = min(int(data.get('count', 100)), 5000)
    days    = int(data.get('days', 1))
    codes   = _load_codes()
    new_codes = []
    for _ in range(count):
        prefix = 'D' if ctype == 'daily' else ('W' if ctype == 'weekly' else 'M')
        code   = prefix + '-' + sec.token_hex(4).upper()
        codes[code] = {
            'type':    ctype,
            'expires': time.time() + days * 86400,
            'used':    False,
            'used_by': None,
            'created': time.time()
        }
        new_codes.append(code)
    _save_codes(codes)
    return jsonify({'ok': True, 'msg': f'✅ تم توليد {count} كود {ctype}', 'codes': new_codes[:50]})

@app.route('/api/codes/check', methods=['POST'])
def api_codes_check():
    data  = request.json or {}
    code  = str(data.get('code', '')).strip().upper()
    valid, ctype, cexp = _validate_code(code)
    if valid:
        import datetime
        exp_str = datetime.datetime.fromtimestamp(cexp).strftime('%Y-%m-%d %H:%M')
        return jsonify({'ok': True, 'valid': True, 'type': ctype, 'expires': exp_str})
    return jsonify({'ok': True, 'valid': False, 'reason': ctype or 'not_found'})

@app.route('/api/codes/export')
def api_codes_export():
    err = _require_admin()
    if err: return err
    codes = _load_codes()
    now   = time.time()
    ctype = request.args.get('type', 'all')
    lines = []
    for code, info in codes.items():
        if info.get('used'): continue
        if now > info.get('expires', 0): continue
        if ctype != 'all' and info['type'] != ctype: continue
        # Add expiry date for clarity
        import datetime
        exp = datetime.datetime.fromtimestamp(info['expires']).strftime('%Y-%m-%d')
        lines.append(f"{code}  [{info['type']} — ينتهي {exp}]")
    text = f"ᶜʰᵉᶠ FIGHT TEAM² — أكواد الدعوة\n"
    text += f"النوع: {ctype} | العدد: {len(lines)}\n"
    text += "=" * 40 + "\n"
    text += '\n'.join(lines)
    from flask import Response
    fname = f'codes_{ctype}.txt'
    return Response(text, mimetype='text/plain; charset=utf-8',
                    headers={'Content-Disposition': f'attachment; filename={fname}',
                             'Content-Type': 'text/plain; charset=utf-8'})

# ─── Main ────────────────────────────────────────────────────────
if __name__ == '__main__':
    port = int(os.environ.get('PORT', 3002))
    print(f"\n🚀 ᶜʰᵉᶠ FIGHT TEAM² → http://0.0.0.0:{port}")
    print(f"🔐 admin / fight2580\n")
    app.run(host='0.0.0.0', port=port, debug=False, threaded=True)
