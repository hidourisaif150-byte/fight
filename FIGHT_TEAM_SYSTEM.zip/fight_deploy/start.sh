#!/bin/bash
# ᶜʰᵉᶠ FIGHT TEAM² — سكريبت التشغيل التلقائي

echo ""
echo "╔══════════════════════════════════════╗"
echo "║   ᶜʰᵉᶠ FIGHT TEAM² - Bot System     ║"
echo "╚══════════════════════════════════════╝"
echo ""

# تحديد مجلد المشروع
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$DIR"

# تثبيت المتطلبات إذا لم تكن موجودة
echo "📦 تثبيت المتطلبات..."
pip install -r requirements.txt -q

# تشغيل السيرفر (يشغّل البوت + اللوحة معاً)
echo ""
echo "🚀 تشغيل السيرفر على المنفذ 3002..."
echo "🌐 افتح المتصفح على: http://YOUR_IP:3002"
echo ""

python server.py
