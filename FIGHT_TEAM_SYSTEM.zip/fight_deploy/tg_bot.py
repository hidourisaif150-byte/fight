import threading
import time
import json
import os
import html
import requests
import base64
from datetime import datetime, timedelta
import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# حاول استيراد AES من Crypto أولاً
try:
    from Crypto.Cipher import AES
    from Crypto.Util.Padding import pad, unpad
    print("✅ تم تحميل مكتبة Crypto بنجاح")
except ImportError:
    try:
        from Cryptodome.Cipher import AES
        from Cryptodome.Util.Padding import pad, unpad
        print("✅ تم تحميل مكتبة Cryptodome بنجاح")
    except ImportError:
        print("❌ يجب تثبيت pycryptodome أولاً: pip install pycryptodome")
        exit()

try:
    from protobuf_decoder.protobuf_decoder import Parser
except ImportError:
    class Parser:
        def parse(self, data):
            return {"error": "protobuf_decoder not installed"}
    print("Warning: protobuf_decoder not available - using dummy parser")

import random
import telebot.types

def safe_story_de_json(obj):
    try:
        return telebot.types.Story(**{k: v for k, v in obj.items() if k != "chat"})
    except Exception:
        return None

telebot.types.Story.de_json = staticmethod(safe_story_de_json)

# بيانات البوت والمسؤول
BOT_TOKEN = "8544968291:AAF6hKzTE55zG3sTDx7U3IzaJK0Uw1f0aHk"
ADMIN_ID = 6271337642  # الإدمن الرئيسي فقط

# قائمة المسؤولين (الإدمن فقط)
ADMIN_IDS = [6271337642,]

# ملفات البيانات
DATA_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "users2.json")
GROUPS_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "groups2.json")
MAINTENANCE_FILE = "maintenance2.json"
SETTINGS_FILE = "bot_settings.json"
RANKS_FILE = "ranks.json"  # ملف الرتب الجديد

# بيانات القناة الإجبارية
SUBSCRIPTION_CHANNEL_ID = -1003869690811 
SUBSCRIPTION_CHANNEL_LINK = "@fight_90"

# بيانات التشفير (من الكود الأول)
ENCRYPTION_KEY = bytes([89, 103, 38, 116, 99, 37, 68, 69, 117, 104, 54, 37, 90, 99, 94, 56])
ENCRYPTION_IV = bytes([54, 111, 121, 90, 68, 114, 50, 50, 69, 51, 121, 99, 104, 106, 77, 37])

# ============== نظام الرتب ==============
class RankSystem:
    # تعريف الرتب ومميزاتها
    RANKS = {
        "عادي": {
            "id": "normal",
            "daily_limit": 2,
            "max_duration": 86400,  # يوم واحد (24 ساعة)
            "color": "#808080",
            "emoji": "👤",
            "commands": ["add", "remove", "myadds", "status", "help"],
            "description": "المستخدم العادي - إضافة حتى 24 ساعة"
        },
        "VIP": {
            "id": "vip",
            "daily_limit": 5,
            "max_duration": 2592000,  # 30 يوم (شهر)
            "color": "#FFD700",
            "emoji": "⭐",
            "commands": ["add", "remove", "myadds", "status", "help", "vipinfo"],
            "description": "مستخدم VIP - إضافة حتى 30 يوم"
        },
        "ماسي": {
            "id": "diamond",
            "daily_limit": 999999,  # غير محدود
            "max_duration": 31536000,  # سنة (365 يوم)
            "color": "#00FFFF",
            "emoji": "💎",
            "commands": ["add", "remove", "myadds", "status", "help", "diamondinfo", "check"],
            "description": "مستخدم ماسي - إضافة بدون حدود"
        },
        "مدير": {
            "id": "admin",
            "daily_limit": 999999,
            "max_duration": 31536000,
            "color": "#FF4500",
            "emoji": "👑",
            "commands": "جميع الأوامر",
            "description": "المسؤول - جميع الصلاحيات"
        }
    }

    def __init__(self):
        self.user_ranks = {}
        self.load_ranks()

    def load_ranks(self):
        """تحميل رتب المستخدمين من الملف"""
        if os.path.exists(RANKS_FILE):
            try:
                with open(RANKS_FILE, "r", encoding="utf-8") as file:
                    self.user_ranks = json.load(file)
                    print(f"✅ تم تحميل {len(self.user_ranks)} رتبة مستخدم")
            except Exception as e:
                print(f"⚠️ خطأ في تحميل الرتب: {e}")
                self.user_ranks = {}

    def save_ranks(self):
        """حفظ رتب المستخدمين في الملف"""
        try:
            with open(RANKS_FILE, "w", encoding="utf-8") as file:
                json.dump(self.user_ranks, file, indent=4, ensure_ascii=False)
            print("✅ تم حفظ الرتب بنجاح")
        except Exception as e:
            print(f"❌ خطأ في حفظ الرتب: {e}")

    def get_user_rank(self, user_id):
        """الحصول على رتبة المستخدم"""
        user_id_str = str(user_id)
        if user_id in ADMIN_IDS:
            return "مدير"
        return self.user_ranks.get(user_id_str, "عادي")

    def set_user_rank(self, user_id, rank_name):
        """تعيين رتبة للمستخدم"""
        if rank_name not in self.RANKS:
            return False
        
        user_id_str = str(user_id)
        self.user_ranks[user_id_str] = rank_name
        self.save_ranks()
        return True

    def get_rank_info(self, rank_name):
        """الحصول على معلومات الرتبة"""
        return self.RANKS.get(rank_name, self.RANKS["عادي"])

    def get_user_rank_info(self, user_id):
        """الحصول على معلومات رتبة المستخدم"""
        rank_name = self.get_user_rank(user_id)
        return self.get_rank_info(rank_name)

    def can_user_use_command(self, user_id, command):
        """التحقق إذا كان المستخدم يمكنه استخدام الأمر"""
        rank_name = self.get_user_rank(user_id)
        rank_info = self.get_rank_info(rank_name)
        
        if rank_name == "مدير":
            return True
        
        if command.startswith('/'):
            command = command[1:]
        
        return command in rank_info["commands"]

    def get_all_ranks(self):
        """الحصول على جميع الرتب"""
        return self.RANKS

# تهيئة نظام الرتب
rank_system = RankSystem()

# ============== إعدادات البوت القابلة للتخصيص ==============
class BotSettings:
    def __init__(self):
        self.settings = {
            "daily_limit_normal": 2,
            "daily_limit_vip": 5,
            "daily_limit_diamond": 999999,
            "default_duration_normal": 86400,  # يوم
            "default_duration_vip": 2592000,  # شهر
            "default_duration_diamond": 31536000,  # سنة
            "max_users": 100,
            "max_duration": 31536000,  # سنة كاملة
            "auto_remove_expired": True,
            "enable_notifications": True,
            "welcome_message": True,
            "allow_all_durations": True,
            "bot_name": "🎮 FREE FIRE RANKS BOT",
            "theme_color": "#FF4500"
        }
        self.load_settings()
    
    def load_settings(self):
        if os.path.exists(SETTINGS_FILE):
            try:
                with open(SETTINGS_FILE, "r", encoding="utf-8") as file:
                    loaded_settings = json.load(file)
                    self.settings.update(loaded_settings)
                    print("✅ تم تحميل إعدادات البوت")
            except:
                print("⚠️ خطأ في تحميل الإعدادات، استخدام الإعدادات الافتراضية")
    
    def save_settings(self):
        with open(SETTINGS_FILE, "w", encoding="utf-8") as file:
            json.dump(self.settings, file, indent=4, ensure_ascii=False)
        print("✅ تم حفظ إعدادات البوت")
    
    def get(self, key):
        return self.settings.get(key)
    
    def set(self, key, value):
        self.settings[key] = value
        self.save_settings()
    
    def get_daily_limit_for_rank(self, rank_name):
        """الحصول على الحد اليومي بناءً على الرتبة"""
        if rank_name == "VIP":
            return self.settings["daily_limit_vip"]
        elif rank_name == "ماسي":
            return self.settings["daily_limit_diamond"]
        elif rank_name == "مدير":
            return 999999
        else:
            return self.settings["daily_limit_normal"]
    
    def get_default_duration_for_rank(self, rank_name):
        """الحصول على المدة الافتراضية بناءً على الرتبة"""
        if rank_name == "VIP":
            return self.settings["default_duration_vip"]
        elif rank_name == "ماسي" or rank_name == "مدير":
            return self.settings["default_duration_diamond"]
        else:
            return self.settings["default_duration_normal"]

bot_settings = BotSettings()

# بيانات الديكور
da = 'f2212101'
dec = ['80', '81', '82', '83', '84', '85', '86', '87', '88', '89', '8a', '8b', '8c', '8d', '8e', '8f', '90', '91', '92', '93', '94', '95', '96', '97', '98', '99', '9a', '9b', '9c', '9d', '9e', '9f', 'a0', 'a1', 'a2', 'a3', 'a4', 'a5', 'a6', 'a7', 'a8', 'a9', 'aa', 'ab', 'ac', 'ad', 'ae', 'af', 'b0', 'b1', 'b2', 'b3', 'b4', 'b5', 'b6', 'b7', 'b8', 'b9', 'ba', 'bb', 'bc', 'bd', 'be', 'bf', 'c0', 'c1', 'c2', 'c3', 'c4', 'c5', 'c6', 'c7', 'c8', 'c9', 'ca', 'cb', 'cc', 'cd', 'ce', 'cf', 'd0', 'd1', 'd2', 'd3', 'd4', 'd5', 'd6', 'd7', 'd8', 'd9', 'da', 'db', 'dc', 'dd', 'de', 'df', 'e0', 'e1', 'e2', 'e3', 'e4', 'e5', 'e6', 'e7', 'e8', 'e9', 'ea', 'eb', 'ec', 'ed', 'ee', 'ef', 'f0', 'f1', 'f2', 'f3', 'f4', 'f5', 'f6', 'f7', 'f8', 'f9', 'fa', 'fb', 'fc', 'fd', 'fe', 'ff']
x = ['1', '01', '02', '03', '04', '05', '06', '07', '08', '09', '0a', '0b', '0c', '0d', '0e', '0f', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19', '1a', '1b', '1c', '1d', '1e', '1f', '20', '21', '22', '23', '24', '25', '26', '27', '28', '29', '2a', '2b', '2c', '2d', '2e', '2f', '30', '31', '32', '33', '34', '35', '36', '37', '38', '39', '3a', '3b', '3c', '3d', '3e', '3f', '40', '41', '42', '43', '44', '45', '46', '47', '48', '49', '4a', '4b', '4c', '4d', '4e', '4f', '50', '51', '52', '53', '54', '55', '56', '57', '58', '59', '5a', '5b', '5c', '5d', '5e', '5f', '60', '61', '62', '63', '64', '65', '66', '67', '68', '69', '6a', '6b', '6c', '6d', '6e', '6f', '70', '71',
     '72', '73', '74', '75', '76', '77', '78', '79', '7a', '7b', '7c', '7d', '7e', '7f']

def generate_random_hex_color():
    top_colors = [
        "FF4500", "FFD700", "32CD32", "87CEEB", "9370DB",
        "FF69B4", "8A2BE2", "00BFFF", "1E90FF", "20B2AA",
        "00FA9A", "008000", "FFFF00", "FF8C00", "DC143C",
        "FF6347", "FFA07A", "FFDAB9", "CD853F", "D2691E",
        "BC8F8F", "F0E68C", "556B2F", "808000", "4682B4",
        "6A5ACD", "7B68EE", "8B4513", "C71585", "4B0082",
        "B22222", "228B22", "8B008B", "483D8B", "556B2F",
        "800000", "008080", "000080", "800080", "808080",
        "A9A9A9", "D3D3D3", "F0F0F0"
    ]
    random_color = random.choice(top_colors)
    return random_color

# وظائف التشفير من الكود الأول
def encrypt_packet(plain_text, key=ENCRYPTION_KEY, iv=ENCRYPTION_IV):
    plain_text_bytes = bytes.fromhex(plain_text)
    cipher = AES.new(key, AES.MODE_CBC, iv)
    cipher_text = cipher.encrypt(pad(plain_text_bytes, AES.block_size))
    return cipher_text.hex()

def decrypt_packet(cipher_text, key=ENCRYPTION_KEY, iv=ENCRYPTION_IV):
    cipher_text_bytes = bytes.fromhex(cipher_text)
    cipher = AES.new(key, AES.MODE_CBC, iv)
    plain_text = unpad(cipher.decrypt(cipher_text_bytes), AES.block_size)
    return plain_text.hex()

def dec_to_hex(ask):
    ask_result = hex(ask)
    final_result = str(ask_result)[2:]
    if len(final_result) == 1:
        final_result = "0" + final_result
        return final_result
    else:
        return final_result

class ParsedResult:
    def __init__(self, field, wire_type, data):
        self.field = field
        self.wire_type = wire_type
        self.data = data

class ParsedResultEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, ParsedResult):
            return {"field": obj.field, "wire_type": obj.wire_type, "data": obj.data}
        return super().default(obj)

def bunner_():
    ra = random.randint(203, 213)
    final_num = str(ra).zfill(3)
    bunner = "902000" + final_num
    bunner = random.choice(numbers)
    return bunner

def create_varint_field(field_number, value):
    field_header = (field_number << 3) | 0
    return encode_varint(field_header) + encode_varint(value)

def create_length_delimited_field(field_number, value):
    field_header = (field_number << 3) | 2
    encoded_value = value.encode() if isinstance(value, str) else value
    return encode_varint(field_header) + encode_varint(len(encoded_value)) + encoded_value

def create_protobuf_packet(fields):
    packet = bytearray()

    for field, value in fields.items():
        if isinstance(value, dict):
            nested_packet = create_protobuf_packet(value)
            packet.extend(create_length_delimited_field(field, nested_packet))
        elif isinstance(value, int):
            packet.extend(create_varint_field(field, value))
        elif isinstance(value, str) or isinstance(value, bytes):
            packet.extend(create_length_delimited_field(field, value))

    return packet

def encode_varint(number):
    if number < 0:
        raise ValueError("Number must be non-negative")

    encoded_bytes = []
    while True:
        byte = number & 0x7F
        number >>= 7
        if number:
            byte |= 0x80
        encoded_bytes.append(byte)
        if not number:
            break
    return bytes(encoded_bytes)

numbers = [
    902000208,
    902000209,
    902000210,
    902000211
]

def Encrypt_ID(number):
    number = int(number)
    encoded_bytes = []
    while True:
        byte = number & 0x7F
        number >>= 7
        if number:
            byte |= 0x80
        encoded_bytes.append(byte)
        if not number:
            break
    return bytes(encoded_bytes).hex()

def Encrypt(number):
    number = int(number)
    encoded_bytes = []
    while True:
        byte = number & 0x7F
        number >>= 7
        if number:
            byte |= 0x80
        encoded_bytes.append(byte)
        if not number:
            break
    return bytes(encoded_bytes).hex()

def Decrypt(encoded_bytes):
    encoded_bytes = bytes.fromhex(encoded_bytes)
    number = 0
    shift = 0
    for byte in encoded_bytes:
        value = byte & 0x7F
        number |= value << shift
        shift += 7
        if not byte & 0x80:
            break
    return number

def decrypt_api(cipher_text):
    return decrypt_packet(cipher_text, ENCRYPTION_KEY, ENCRYPTION_IV)

def encrypt_api(plain_text):
    return encrypt_packet(plain_text, ENCRYPTION_KEY, ENCRYPTION_IV)

# وظائف JWT المدمجة مباشرة
def TOKEN_MAKER(OLD_ACCESS_TOKEN, NEW_ACCESS_TOKEN, OLD_OPEN_ID, NEW_OPEN_ID, uid):
    now = datetime.now()
    now = str(now)[:len(str(now)) - 7]
    data = bytes.fromhex('1a13323032352d30372d33302031313a30323a3531220966726565206669726528013a07312e3131342e32422c416e64726f6964204f5320372e312e32202f204150492d323320284e32473438382f373030323530323234294a0848616e6468656c645207416e64726f69645a045749464960c00c68840772033332307a1f41524d7637205646507633204e454f4e20564d48207c2032343635207c203480019a1b8a010f416472656e6f2028544d292036343092010d4f70656e474c20455320332e319a012b476f6f676c657c31663361643662372d636562342d343934622d383730622d623164616364373230393131a2010c3139372e312e31322e313335aa0102656eb201203939366136323964626364623339363462653662363937386635643831346462ba010134c2010848616e6468656c64ca011073616d73756e6720534d2d473935354eea014066663930633037656239383135616633306134336234613966363031393531366530653463373033623434303932353136643064656661346365663531663261f00101ca0207416e64726f6964d2020457494649ca03203734323862323533646566633136343031386336303461316562626665626466e003daa907e803899b07f003bf0ff803ae088004999b078804daa9079004999b079804daa907c80403d204262f646174612f6170702f636f6d2e6474732e667265656669726574682d312f6c69622f61726de00401ea044832303837663631633139663537663261663465376665666630623234643964397c2f646174612f6170702f636f6d2e6474732e667265656669726574682d312f626173652e61704bf00403f804018a050233329a050a32303139313138363933a80503b205094f70656e474c455332b805ff7fc00504e005dac901ea0507616e64726f6964f2055c4b71734854394748625876574c6668437950416c52526873626d43676542557562555551317375746d525536634e30524f3751453141486e496474385963784d614c575437636d4851322b7374745279377830663935542b6456593d8806019006019a060134a2060134b2061e40001147550d0c074f530b4d5c584d57416657545a065f2a091d6a0d5033')
    data = data.replace(OLD_OPEN_ID.encode(), NEW_OPEN_ID.encode())
    data = data.replace(OLD_ACCESS_TOKEN.encode(), NEW_ACCESS_TOKEN.encode())
    d = encrypt_api(data.hex())
    Final_Payload = bytes.fromhex(d)
    
    headers = {
        "Host": "loginbp.ggblueshark.com",
        "X-Unity-Version": "2018.4.11f1",
        "Accept": "*/*",
        "Authorization": "Bearer",
        "ReleaseVersion": "OB52",
        "X-GA": "v1 1",
        "Accept-Encoding": "gzip, deflate, br",
        "Accept-Language": "en-GB,en-US;q=0.9,en;q=0.8",
        "Content-Type": "application/x-www-form-urlencoded",
        "Content-Length": str(len(Final_Payload)),
        "User-Agent": "Free%20Fire/2019118692 CFNetwork/3826.500.111.2.2 Darwin/24.4.0",
        "Connection": "keep-alive"
    }
    
    URL = "https://loginbp.ggblueshark.com/MajorLogin"
    RESPONSE = requests.post(URL, headers=headers, data=Final_Payload, verify=False)
    
    if RESPONSE.status_code == 200:
        if len(RESPONSE.text) < 10:
            return False
        BASE64_TOKEN = RESPONSE.text[RESPONSE.text.find("eyJhbGciOiJIUzI1NiIsInN2ciI6IjEiLCJ0eXAiOiJKV1QifQ"):-1]
        second_dot_index = BASE64_TOKEN.find(".", BASE64_TOKEN.find(".") + 1)
        BASE64_TOKEN = BASE64_TOKEN[:second_dot_index + 44]
        return BASE64_TOKEN
    else:
        print(f"MajorLogin failed with status: {RESPONSE.status_code}")
        print(f"Response: {RESPONSE.text}")
        return False

def fetch_jwt_token_direct():
    """جلب التوكن مباشرة بدون استخدام API خارجي"""
    try:
        uid = "4637319967"
        password = "C31DCB208729E2E6D31C3B1983BD472739B7A06AE35668FA36967D3180EC8031"
        
        url = "https://100067.connect.garena.com/oauth/guest/token/grant"
        headers = {
            "Host": "100067.connect.garena.com",
            "User-Agent": "GarenaMSDK/4.0.19P4(G011A ;Android 9;en;US;)",
            "Content-Type": "application/x-www-form-urlencoded",
            "Accept-Encoding": "gzip, deflate, br",
            "Connection": "close",
        }
        data = {
            "uid": f"{uid}",
            "password": f"{password}",
            "response_type": "token",
            "client_type": "2",
            "client_secret": "",
            "client_id": "100067",
        }
        
        response = requests.post(url, headers=headers, data=data)
        print(f"📩 استجابة Garena API: {response.text}")
        
        data = response.json()
        
        if "access_token" not in data or "open_id" not in data:
            print(f"❌ مفاتيح مفقودة في الاستجابة: {data}")
            return None

        NEW_ACCESS_TOKEN = data['access_token']
        NEW_OPEN_ID = data['open_id']
        OLD_ACCESS_TOKEN = "ff90c07eb9815af30a43b4a9f6019516e0e4c703b44092516d0defa4cef51f2a"
        OLD_OPEN_ID = "996a629dbcdb3964be6b6978f5d814db"
        
        token = TOKEN_MAKER(OLD_ACCESS_TOKEN, NEW_ACCESS_TOKEN, OLD_OPEN_ID, NEW_OPEN_ID, uid)
        if token:
            print(f"✅ تم توليد التوكن بنجاح: {token}")
            return token
        else:
            print("❌ فشل توليد التوكن")
            return None
            
    except Exception as e:
        print(f"⚠️ خطأ أثناء جلب التوكن مباشرة: {e}")
        return None

# وظائف API المحدثة مع الـ Headers الجديدة
def send_friend_request(player_id):
    """إرسال طلب صداقة - الإصدار المُبسط"""
    global JWT_TOKEN
    if not JWT_TOKEN:
        return "⚠️ التوكن غير متاح حاليًا أو غير صالح. يرجى محاولة التحديد يدوياً أو انتظار التحديث الدوري."
    
    enc_id = Encrypt_ID(player_id)
    payload = f"08a7c4839f1e10{enc_id}1801" 
    encrypted_payload = encrypt_api(payload)
    
    url = "https://clientbp.ggblueshark.com/RequestAddingFriend"
    headers = {
        "Authorization": f"Bearer {JWT_TOKEN}",
        "X-Unity-Version": "2018.4.11f1",
        "X-GA": "v1 1",
        "ReleaseVersion": "OB52",
        "Content-Type": "application/x-www-form-urlencoded",
        "User-Agent": "Dalvik/2.1.0 (Linux; Android 9)",
        "Connection": "Keep-Alive",
        "Accept-Encoding": "gzip"
    }
    
    try:
        r = requests.post(url, headers=headers, data=bytes.fromhex(encrypted_payload), timeout=15, verify=False)
        
        if r.status_code == 200:
            # تحليل الاستجابة المبسط
            if "BR_FRIEND_NOT_SAME_REGION" in r.text:
                return "❌ لا يمكن إضافة اللاعب لأنه ليس في نفس منطقتك (السيرفر)"
            
            # إذا وصلنا هنا يعني الإضافة ناجحة
            return "✅ تم إرسال طلب الصداقة بنجاح!"
                    
        elif r.status_code == 400:
            if "BR_FRIEND_NOT_SAME_REGION" in r.text:
                return "❌ لا يمكن إضافة اللاعب لأنه ليس في نفس منطقتك (السيرفر)"
            return "❌ خطأ في الطلب - قد يكون اللاعب من منطقة مختلفة"
        elif r.status_code == 401:
            JWT_TOKEN = None
            return "❌ التوكن غير صالح أو منتهي الصلاحية. سيتم محاولة تحديثه."
        elif r.status_code == 404:
            return "❌ اللاعب غير موجود أو خطأ في الاتصال بنقطة النهاية."
        else:
            return f"❌ فشل إرسال الطلب. كود الخطأ: {r.status_code}"
            
    except Exception as e:
        return f"❌ حدث خطأ أثناء إرسال الطلب: {str(e)}"

def remove_friend(player_id):
    """حذف صديق - الإصدار المُبسط والمُحسن للتشخيص"""
    global JWT_TOKEN
    if not JWT_TOKEN:
        return "⚠️ التوكن غير متاح حاليًا أو غير صالح. يرجى محاولة التحديد يدوياً أو انتظار التحديث الدوري."
    
    enc_id = Encrypt_ID(player_id)
    # الحمولة المشتبه بها
    payload = f"08a7c4839f1e10{enc_id}1802"  
    encrypted_payload = encrypt_api(payload)
    
    url = "https://clientbp.ggblueshark.com/RemoveFriend"
    headers = {
        "Authorization": f"Bearer {JWT_TOKEN}",
        "X-Unity-Version": "2018.4.11f1",
        "X-GA": "v1 1",
        "ReleaseVersion": "OB52",
        "Content-Type": "application/x-www-form-urlencoded",
        "User-Agent": "Dalvik/2.1.0 (Linux; Android 9)",
        "Connection": "Keep-Alive",
        "Accept-Encoding": "gzip"
    }
    
    try:
        r = requests.post(url, headers=headers, data=bytes.fromhex(encrypted_payload), timeout=15, verify=False)
        
        if r.status_code == 200:
            return "✅ تم الحذف بنجاح!"
        elif r.status_code == 401:
            JWT_TOKEN = None
            return "❌ التوكن غير صالح أو منتهي الصلاحية. سيتم محاولة تحديثه."
        elif r.status_code == 400:
            server_error = r.text.strip()
            if server_error:
                 return f"❌ فشل الحذف. كود الخطأ: 400. استجابة السيرفر: {server_error}"
            return "❌ فشل الحذف. كود الخطأ: 400 (طلب سيئ - تحقق من الحمولة Protobuf)."
        elif r.status_code == 404:
            return "❌ اللاعب غير موجود في قائمة الأصدقاء (أو خطأ اتصال)."
        else:
            return f"❌ فشل الحذف. كود الخطأ: {r.status_code}"
            
    except Exception as e:
        return f"❌ حدث خطأ أثناء الحذف: {str(e)}"
        
def load_users():
    if os.path.exists(DATA_FILE):
        with open(DATA_FILE, "r", encoding="utf-8") as file:
            try:
                data = json.load(file)
                if isinstance(data, dict):
                    return data
            except json.JSONDecodeError:
                pass
    return {}

def save_users():
    with open(DATA_FILE, "w", encoding="utf-8") as file:
        json.dump(users, file, ensure_ascii=False, indent=4)

def load_groups():
    if os.path.exists(GROUPS_FILE):
        with open(GROUPS_FILE, "r", encoding="utf-8") as file:
            try:
                data = json.load(file)
                if isinstance(data, dict):
                    return {k: v for k, v in data.items()}
            except json.JSONDecodeError:
                pass
    return {}

def save_groups():
    with open(GROUPS_FILE, "w", encoding="utf-8") as file:
        json.dump(group_activations, file, ensure_ascii=False, indent=4)

def load_maintenance_status():
    if os.path.exists(MAINTENANCE_FILE):
        with open(MAINTENANCE_FILE, "r", encoding="utf-8") as file:
            try:
                return json.load(file).get("maintenance_mode", False)
            except json.JSONDecodeError:
                pass
    return False

def save_maintenance_status(status):
    with open(MAINTENANCE_FILE, "w", encoding="utf-8") as file:
        json.dump({"maintenance_mode": status}, file)

def is_admin(message):
    """التحقق إذا كان المستخدم من المسؤولين"""
    user_id = message.from_user.id if hasattr(message, 'from_user') else message
    return user_id in ADMIN_IDS

def get_user_rank(message):
    """الحصول على رتبة المستخدم"""
    user_id = message.from_user.id if hasattr(message, 'from_user') else message
    return rank_system.get_user_rank(user_id)

def get_user_rank_info(message):
    """الحصول على معلومات رتبة المستخدم"""
    user_id = message.from_user.id if hasattr(message, 'from_user') else message
    return rank_system.get_user_rank_info(user_id)

def is_allowed_group(message):
    chat_id_str = str(message.chat.id)
    if chat_id_str in group_activations:
        expiry_timestamp = group_activations[chat_id_str]
        if expiry_timestamp > time.time():
            return True
        else:
            del group_activations[chat_id_str]
            save_groups()
            bot.send_message(message.chat.id, "⚠️ انتهت صلاحية تفعيل البوت في هذه المجموعة.\nيرجى التواصل مع لإعادة التفعيل.", parse_mode="Markdown")
            return False
    else:
        bot.send_message(message.chat.id, "⚠️ البوت غير مفعل في هذه المجموعة.\nيرجى التواصل مع  لكي يقوم بتفعيل البوت.", parse_mode="Markdown")
        return False

def is_subscribed(message):
    try:
        status = bot.get_chat_member(SUBSCRIPTION_CHANNEL_ID, message.from_user.id).status
        return status in ['member', 'administrator', 'creator']
    except telebot.apihelper.ApiTelegramException as e:
        if "chat not found" in str(e) or "user not found" in str(e):
            print(f"Error checking subscription: {e}")
            return False
        return False

def format_remaining_time(expiry_time):
    remaining = int(expiry_time - time.time())
    if remaining <= 0:
        return "⛔ انتهت الصلاحية"

    years = remaining // (365 * 86400)
    months = (remaining % (365 * 86400)) // (30 * 86400)
    days = (remaining % (30 * 86400)) // 86400
    hours = (remaining % 86400) // 3600
    minutes = (remaining % 3600) // 60
    seconds = remaining % 60

    parts = []
    if years > 0:
        parts.append(f"{years} سنة")
    if months > 0:
        parts.append(f"{months} شهر")
    if days > 0:
        parts.append(f"{days} ")
    if hours > 0:
        parts.append(f"{hours} ساعة")
    if minutes > 0:
        parts.append(f"{minutes} دقيقة")
    if seconds > 0 and len(parts) < 2:
        parts.append(f"{seconds} ثانية")

    return " و ".join(parts[:3])

def fetch_jwt_token():
    """استخدام الوظيفة المدمجة مباشرة لجلب التوكن"""
    return fetch_jwt_token_direct()

def update_jwt_periodically():
    global JWT_TOKEN
    while True:
        new_token = fetch_jwt_token()
        if new_token:
            JWT_TOKEN = new_token
            print("🔄 تم تحديث التوكن بنجاح")
        else:
            print("⚠️ فشل تحديث التوكن، سيتم المحاولة لاحقاً")
        time.sleep(5 * 3600)  # تحديث كل 5 ساعات

def remove_expired_users():
    now = time.time()
    expired = [uid for uid, d in users.items() if d.get("expiry") and d["expiry"] <= now]
    for uid in expired:
        if "added_by_tele_id" in users[uid]:
            try:
                remove_friend(uid)
            except:
                pass
        del users[uid]
    save_users()

def check_expired_users():
    while True:
        remove_expired_users()
        time.sleep(60)

def reset_daily_adds():
    now = datetime.now()
    for tele_id in list(users.keys()):
        if isinstance(users[tele_id], dict) and 'last_reset_day' in users[tele_id]:
            last_reset = datetime.fromtimestamp(users[tele_id]['last_reset_day'])
            if now.date() > last_reset.date():
                users[tele_id]['adds_today'] = 0
                users[tele_id]['last_reset_day'] = now.timestamp()
    save_users()

def daily_reset_timer():
    while True:
        reset_daily_adds()
        time.sleep(3600)

def get_total_users_count():
    """الحصول على عدد المستخدمين الفعليين في القائمة"""
    count = 0
    for uid, data in users.items():
        if isinstance(data, dict) and "name" in data and "expiry" in data:
            count += 1
    return count

def parse_time_duration(time_str, rank_name):
    """تحويل نص الوقت إلى ثواني مع مراعاة الرتبة"""
    time_str = time_str.lower().strip()
    
    # إذا كان رقم فقط، نعتبره أيام
    if time_str.isdigit():
        days = int(time_str)
        max_days = rank_system.get_rank_info(rank_name)["max_duration"] // 86400
        if days > max_days:
            days = max_days
        return days * 86400
    
    # إذا كان يحتوي على حرف
    if 'y' in time_str:  # سنوات
        years = int(time_str.replace('y', ''))
        max_years = rank_system.get_rank_info(rank_name)["max_duration"] // 31536000
        if years > max_years:
            years = max_years
        return years * 365 * 86400
    elif 'w' in time_str:  # أسابيع
        weeks = int(time_str.replace('w', ''))
        max_weeks = rank_system.get_rank_info(rank_name)["max_duration"] // (7 * 86400)
        if weeks > max_weeks:
            weeks = max_weeks
        return weeks * 7 * 86400
    elif 'd' in time_str:  # أيام
        days = int(time_str.replace('d', ''))
        max_days = rank_system.get_rank_info(rank_name)["max_duration"] // 86400
        if days > max_days:
            days = max_days
        return days * 86400
    elif 'h' in time_str:  # ساعات
        hours = int(time_str.replace('h', ''))
        max_hours = rank_system.get_rank_info(rank_name)["max_duration"] // 3600
        if hours > max_hours:
            hours = max_hours
        return hours * 3600
    elif 'm' in time_str:  # دقائق
        minutes = int(time_str.replace('m', ''))
        max_minutes = rank_system.get_rank_info(rank_name)["max_duration"] // 60
        if minutes > max_minutes:
            minutes = max_minutes
        return minutes * 60
    elif 's' in time_str:  # ثواني
        seconds = int(time_str.replace('s', ''))
        if seconds > rank_system.get_rank_info(rank_name)["max_duration"]:
            seconds = rank_system.get_rank_info(rank_name)["max_duration"]
        return seconds
    else:
        # إذا كان تنسيق غير معروف، نستخدم الإعداد الافتراضي للرتبة
        return bot_settings.get_default_duration_for_rank(rank_name)

def format_duration(seconds):
    """تنسيق المدة لعرضها للمستخدم"""
    if seconds >= 31536000:  # سنة
        years = seconds // 31536000
        remaining = seconds % 31536000
        days = remaining // 86400
        if days > 0:
            return f"{years} سنة و {days} يوم"
        return f"{years} سنة"
    elif seconds >= 86400:  # أيام
        days = seconds // 86400
        remaining = seconds % 86400
        hours = remaining // 3600
        if hours > 0:
            return f"{days} يوم و {hours} ساعة"
        return f"{days} يوم"
    elif seconds >= 3600:  # ساعات
        hours = seconds // 3600
        remaining = seconds % 3600
        minutes = remaining // 60
        if minutes > 0:
            return f"{hours} ساعة و {minutes} دقيقة"
        return f"{hours} ساعة"
    elif seconds >= 60:  # دقائق
        minutes = seconds // 60
        return f"{minutes} دقيقة"
    else:  # ثواني
        return f"{seconds} ثانية"

def get_player_info(uid):
    """
    جلب معلومات اللاعب من API الجديد
    API: https://lonely-info-2.vercel.app/get?uid=
    """
    try:
        api_url = f"https://lonely-info-2.vercel.app/get?uid={uid}"
        res = requests.get(api_url, timeout=10)
        
        if res.status_code != 200:
            print(f"⚠️ Error: API returned status {res.status_code}")
            return "غير معروف", "N/A", "N/A"
        
        data = res.json()
        
        if not isinstance(data, dict):
            print(f"⚠️ Error: Invalid response format")
            return "غير معروف", "N/A", "N/A"
        
        if "AccountInfo" in data:
            account_info = data["AccountInfo"]
            name = account_info.get("AccountName", "غير معروف")
            region = account_info.get("AccountRegion", "N/A")
            level = account_info.get("AccountLevel", "N/A")
            
            if name and name != "غير معروف":
                name = html.unescape(name)
            
            return name, region, level
        else:
            name = "غير معروف"
            region = "N/A"
            level = "N/A"
            
            if "socialinfo" in data:
                name = data["socialinfo"].get("accountId", "غير معروف")
            
            for key, value in data.items():
                if isinstance(value, dict) and "nickname" in str(value):
                    for sub_key, sub_value in value.items():
                        if "name" in sub_key.lower():
                            name = sub_value
                        elif "region" in sub_key.lower():
                            region = sub_value
                        elif "level" in sub_key.lower():
                            level = sub_value
            
            return name, region, level
            
    except requests.exceptions.Timeout:
        print(f"⚠️ Timeout fetching info for {uid}")
        return "غير معروف", "N/A", "N/A"
    except requests.exceptions.RequestException as e:
        print(f"⚠️ Network error fetching info for {uid}: {e}")
        return "غير معروف", "N/A", "N/A"
    except json.JSONDecodeError as e:
        print(f"⚠️ JSON decode error for {uid}: {e}")
        return "غير معروف", "N/A", "N/A"
    except Exception as e:
        print(f"⚠️ Unexpected error fetching info for {uid}: {e}")
        return "غير معروف", "N/A", "N/A"

# ============== تهيئة المتغيرات ==============

users = load_users()
group_activations = load_groups()
maintenance_mode = load_maintenance_status()
bot = telebot.TeleBot(BOT_TOKEN)

print("🔄 جاري جلب التوكن للمرة الأولى...")
for _ in range(5):
    JWT_TOKEN = fetch_jwt_token()
    if JWT_TOKEN:
        print("✅ تم جلب التوكن بنجاح!")
        break
    time.sleep(3)
else:
    print("❌ فشل جلب التوكن بعد 5 محاولات!")

if not JWT_TOKEN:
    print("⚠️ تحذير: البوت يعمل بدون توكن، قد لا تعمل بعض الوظائف!")

threading.Thread(target=update_jwt_periodically, daemon=True).start()
threading.Thread(target=check_expired_users, daemon=True).start()
threading.Thread(target=daily_reset_timer, daemon=True).start()

def send_message_to_all_groups(message_text):
    for chat_id in list(group_activations.keys()):
        try:
            bot.send_message(chat_id, message_text, parse_mode="Markdown")
            time.sleep(1)
        except telebot.apihelper.ApiTelegramException as e:
            if "chat not found" in str(e) or "bot was kicked from the group chat" in str(e):
                print(f"⚠️ فشل إرسال رسالة إلى المجموعة {chat_id}: تم حذف المجموعة أو البوت ليس عضواً. سيتم حذفها من القائمة.")
                del group_activations[chat_id]
                save_groups()
            else:
                print(f"⚠️ فشل إرسال رسالة إلى المجموعة {chat_id}: {e}")

# ============== أوامر الرتب للمستخدمين في المجموعات ==============

@bot.message_handler(commands=['start', 'help'], chat_types=['group', 'supergroup'])
def handle_group_commands(message):
    """أوامر المستخدمين في المجموعات فقط مع نظام الرتب"""
    if not is_allowed_group(message):
        return

    if maintenance_mode and not is_admin(message):
        bot.reply_to(message, "⚙️ البوت في وضع الصيانة حالياً.\nسوف يتم إعادته بعد الانتهاء من الصيانة.\nنعتذر على الازعاج.", parse_mode="Markdown")
        return

    user_rank = get_user_rank(message)
    rank_info = rank_system.get_rank_info(user_rank)
    daily_limit = bot_settings.get_daily_limit_for_rank(user_rank)
    default_duration = bot_settings.get_default_duration_for_rank(user_rank)
    
    help_text = f"""
{rank_info['emoji']} *🔥 {rank_info['description']} 🔥* {rank_info['emoji']}
════════════════════════════════════

✨ *مرحباً بك في بوت الإضافة الآلي لفري فاير!* ✨
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

📋 *🔹 الأوامر المتاحة 🔹*

🎯 *إضافة لاعب (حسب رتبتك):*
• `/add <الأيدي>` - إضافة لمدة {format_duration(default_duration)}
• `/add <الأيدي> <الوقت>` - إضافة مع تحديد المدة

⏳ *أمثلة للمدة حسب رتبتك ({user_rank}):*
┌─────────────────────────────┐"""
    
    # إضافة أمثلة حسب الرتبة
    if user_rank == "عادي":
        help_text += """
│  `/add 123456`      24 ساعة │
│  `/add 123456 1d`   يوم واحد│
│  `/add 123456 12h`  12 ساعة │
│  `/add 123456 30m`  30 دقيقة│"""
    elif user_rank == "VIP":
        help_text += """
│  `/add 123456`      شهر واحد│
│  `/add 123456 7d`   7 أيام  │
│  `/add 123456 15d`  15 يوم  │
│  `/add 123456 30d`  30 يوم  │"""
    elif user_rank == "ماسي" or user_rank == "مدير":
        help_text += """
│  `/add 123456`      سنة كاملة│
│  `/add 123456 7d`   7 أيام  │
│  `/add 123456 30d`  30 يوم  │
│  `/add 123456 90d`  90 يوم  │
│  `/add 123456 365d` سنة كاملة│"""
    
    help_text += f"""
└─────────────────────────────┘

🛠️ *الأوامر الأخرى المتاحة لك:*
"""
    
    # عرض الأوامر حسب الرتبة
    for cmd in rank_info["commands"]:
        if cmd == "add":
            help_text += "• `/add <id> <الوقت>` - إضافة لاعب\n"
        elif cmd == "remove":
            help_text += "• `/remove <id>` - حذف لاعب\n"
        elif cmd == "myadds":
            help_text += "• `/myadds` - عرض إحصائياتك اليومية\n"
        elif cmd == "status":
            help_text += "• `/status` - حالة البوت الحالية\n"
        elif cmd == "vipinfo":
            help_text += "• `/vipinfo` - معلومات حساب VIP\n"
        elif cmd == "diamondinfo":
            help_text += "• `/diamondinfo` - معلومات حساب ماسي\n"
        elif cmd == "check":
            help_text += "• `/check <id>` - التحقق من لاعب\n"
    
    help_text += f"""
🎨 *🎯 تنسيق الوقت الكامل 🎯*
┌─────────────────────────────┐
│  `s` = ثواني                │
│  `m` = دقائق                │
│  `h` = ساعات                │
│  `d` = أيام                  │
│  `w` = أسابيع               │
│  `y` = سنوات                │
└─────────────────────────────┘

📊 *📈 ميزات رتبتك ({user_rank}) 📈*
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
✅ *إضافة حتى {format_duration(rank_info['max_duration'])}*
✅ *معلومات اللاعب كاملة*
✅ *إزالة سهلة وسريعة*
✅ *متابعة المدة المتبقية*
✅ *دعم فني سريع*

⚡ *🎁 الحد اليومي لرتبتك 🎁*
┌─────────────────────────────┐
│  • {daily_limit} إضافة لكل مستخدم يومياً│
│  • تجدد الإضافات كل 24 ساعة │
│  • الحد الأقصى {bot_settings.get('max_users')} حساب │
└─────────────────────────────┘

💎 *✨ ترقية رتبتك ✨*
للترقية إلى رتبة أعلى، تواصل مع المطور على :

Insta☞@saifislem77


Telegram☞@fight_90

https://guns.lol/fight_90

حالي توصلو معي انا فقط عبر الموقع لشراء اي شيئ وشكرا لكم 

{rank_info['emoji']} *🚀 استمتع بتجربة الإضافة المميزة! 🚀* {rank_info['emoji']}
════════════════════════════════════
    """
    
    bot.reply_to(message, help_text, disable_web_page_preview=True)
@bot.message_handler(commands=['add'], chat_types=['group', 'supergroup'])
def add_user_group(message):
    """أمر إضافة اللاعب في المجموعات مع نظام الرتب"""
    if not is_allowed_group(message):
        return

    if maintenance_mode and not is_admin(message):
        bot.reply_to(message, "⚙️ البوت في وضع الصيانة حالياً.\nسوف يتم إعادته بعد الانتهاء من الصيانة.\nنعتذر على الازعاج.", parse_mode="Markdown")
        return

    # التحقق من الحد الأقصى للقائمة
    current_count = get_total_users_count()
    if current_count >= bot_settings.get("max_users"):
        bot.reply_to(message, f"""❌ *وصل البوت للحد الأقصى من الإضافات ({bot_settings.get('max_users')} حساب)!*

📌 *يرجى الانتظار حتى يتم تحرير بعض المساحة.*
💡 *يمكن للمسؤول إزالة بعض الإضافات.*""", parse_mode="Markdown")
        return

    user_tele_id = str(message.from_user.id)
    user_rank = get_user_rank(message)
    rank_info = rank_system.get_rank_info(user_rank)
    daily_limit = bot_settings.get_daily_limit_for_rank(user_rank)
    
    if not is_admin(message):
        now = datetime.now()
        if user_tele_id not in users or not isinstance(users[user_tele_id], dict):
            users[user_tele_id] = {"adds_today": 0, "last_reset_day": now.timestamp(), "rank": user_rank}
            save_users()
        else:
            last_reset = datetime.fromtimestamp(users[user_tele_id].get("last_reset_day", 0))
            if now.date() > last_reset.date():
                users[user_tele_id]["adds_today"] = 0
                users[user_tele_id]["last_reset_day"] = now.timestamp()
                save_users()

        if users[user_tele_id].get("adds_today", 0) >= daily_limit:
            next_reset = ((time.time() // 86400) + 1) * 86400
            time_to_reset = format_duration(next_reset - time.time())
            
            bot.reply_to(message, f"""⚠️ *عذراً! لقد وصلت للحد الأقصى اليومي*

📊 *إحصائياتك اليومية:*
🎖️ *رتبتك:* {user_rank} {rank_info['emoji']}
✅ *عدد الإضافات اليوم:* {users[user_tele_id]["adds_today"]}
🎯 *الحد اليومي لرتبتك:* {daily_limit}
🔄 *تتجدد الإضافات بعد:* {time_to_reset}

💎 *للترقية إلى رتبة أعلى مع حدود أكبر:*

✨ *يمكنك الإضافة مجدداً بعد منتصف الليل*""", parse_mode="Markdown")
            return

    try:
        parts = message.text.split()
        if len(parts) < 2:
            default_duration = format_duration(bot_settings.get_default_duration_for_rank(user_rank))
            bot.reply_to(message, f"""❌ *الاستخدام الصحيح:*

`/add <الأيدي> [الوقت]`

🎯 *أمثلة متقدمة لرتبتك ({user_rank}):*
• `/add 123456789` - {default_duration} (افتراضي)
• `/add 123456 1d` - يوم واحد
• `/add 123456 7d` - 7 أيام""", parse_mode="Markdown")
            return

        game_id = parts[1]

        if not game_id.isdigit():
            bot.reply_to(message, "❌ *خطأ:* الأيدي يجب أن يحتوي على أرقام فقط.")
            return

        # تحديد المدة
        if len(parts) >= 3:
            time_duration = parse_time_duration(parts[2], user_rank)
        else:
            time_duration = bot_settings.get_default_duration_for_rank(user_rank)

        # التحقق أولاً إذا كان اللاعب موجودًا بالفعل
        if game_id in users:
            remaining = format_remaining_time(users[game_id]["expiry"])
            name = users[game_id]["name"]
            bot.reply_to(message, f"""❌ *هذا اللاعب مضاف بالفعل!*

👤 *الاسم:* {name}
🆔 *الأيدي:* `{game_id}`
⏳ *المدة المتبقية:* {remaining}

✨ *يمكنك إزالته أولاً باستخدام:*
`/remove {game_id}`""", parse_mode="Markdown")
            return

        # إرسال طلب الإضافة
        bot.reply_to(message, "🔄 *جاري إرسال طلب الصداقة...*", parse_mode="Markdown")
        response = send_friend_request(game_id)
        
        if "✅" in response:
            name, region, level = get_player_info(game_id)

            users[game_id] = {
                "name": name,
                "expiry": time.time() + time_duration,
                "added_by_tele_id": user_tele_id,
                "added_by_tele_username": message.from_user.username or "بدون معرف",
                "added_date": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "duration_seconds": time_duration,
                "added_by_rank": user_rank
            }

            if not is_admin(message):
                users[user_tele_id]["adds_today"] = users[user_tele_id].get("adds_today", 0) + 1
                users[user_tele_id]["rank"] = user_rank

            save_users()
            
            formatted_duration = format_duration(time_duration)
            expiry_date = datetime.fromtimestamp(time.time() + time_duration).strftime("%Y-%m-%d %H:%M:%S")
            
            # تحضير رسالة النجاح مع تصميم جميل
            success_message = f"""
🎉 *✅ تمت الإضافة بنجاح! ✅*

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🎖️ *رتبة المضيف:* {user_rank} {rank_info['emoji']}
👤 *معلومات اللاعب:*
├ **الاسم:** {name}
├ **الأيدي:** `{game_id}`
├ **المنطقة:** {region}
└ **المستوى:** {level}

⏳ *معلومات المدة:*
├ **المدة المضافة:** {formatted_duration}
├ **ينتهي في:** {expiry_date}
└ **نوع الإضافة:** {user_rank}

📊 *إحصائياتك:*
├ **الإضافات اليوم:** {users[user_tele_id].get('adds_today', 1) if user_tele_id in users else 1}/{daily_limit}
├ **المتبقي اليوم:** {daily_limit - (users[user_tele_id].get('adds_today', 0) if user_tele_id in users else 0)}
└ **الإجمالي في البوت:** {get_total_users_count()}/{bot_settings.get('max_users')}

⚠️ *ملاحظة هامة:*
• يرجى قبول طلب الصداقة في اللعبة!
• يمكنك إزالة اللاعب في أي وقت

🔧 *لإزالة اللاعب:*
`/remove {game_id}`
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

✨ *شكراً لاستخدامك البوت!* ✨
            """
            bot.reply_to(message, success_message, parse_mode="Markdown")
        else:
            error_msg = f"""❌ *فشل في الإضافة!*

📌 *تفاصيل الخطأ:*
{response}

💡 *نصائح لحل المشكلة:*
1. تأكد من صحة الأيدي
2. تحقق من أن اللاعب في نفس المنطقة
3. حاول مرة أخرى بعد قليل
4. تأكد من أن اللاعب ليس مضافاً مسبقاً

🔧 *للإبلاغ عن مشكلة:"""
            bot.reply_to(message, error_msg, parse_mode="Markdown", disable_web_page_preview=True)
            
    except Exception as e:
        print(f"[ADD_ERROR] {e}")
        error_msg = f"""❌ *حدث خطأ غير متوقع!*

📌 *تفاصيل الخطأ:*
`{str(e)}`

🔧 *يرجى المحاولة مرة أخرى أو التواصل مع الدعم:* """
        bot.reply_to(message, error_msg, parse_mode="Markdown", disable_web_page_preview=True)

@bot.message_handler(commands=['remove'], chat_types=['group', 'supergroup'])
def remove_user_group(message):
    """أمر إزالة اللاعب في المجموعات مع نظام الرتب"""
    if not is_allowed_group(message):
        return

    if maintenance_mode and not is_admin(message):
        bot.reply_to(message, "⚙️ البوت في وضع الصيانة حالياً.\nسوف يتم إعادته بعد الانتهاء من الصيانة.\nنعتذر على الازعاج.", parse_mode="Markdown")
        return

    try:
        parts = message.text.split()
        if len(parts) != 2:
            user_rank = get_user_rank(message)
            bot.reply_to(message, f"""❌ *الاستخدام الصحيح:*

`/remove <الأيدي>`

📌 *مثال:*
`/remove 123456789`

💡 *ملاحظة:*
يمكنك إزالة اللاعبين الذين أضفتهم فقط
🎖️ *رتبتك:* {user_rank}""", parse_mode="Markdown")
            return

        game_id_to_remove = parts[1]
        user_tele_id = str(message.from_user.id)

        if game_id_to_remove in users:
            if not is_admin(message) and users[game_id_to_remove].get("added_by_tele_id") != user_tele_id:
                user_rank = get_user_rank(message)
                bot.reply_to(message, f"""❌ *غير مسموح لك بحذف هذا الأيدي!*

🎖️ *رتبتك:* {user_rank}

📌 *الأسباب المحتملة:*
1. لم تقم بإضافة هذا اللاعب
2. اللاعب مضاف بواسطة مستخدم آخر
3. اللاعب مضاف بواسطة المسؤول

💡 *يمكنك فقط حذف اللاعبين الذين أضفتهم أنت*""", parse_mode="Markdown")
                return

            name = users[game_id_to_remove]['name']
            bot.reply_to(message, f"🔄 *جاري حذف اللاعب...*", parse_mode="Markdown")
            response = remove_friend(game_id_to_remove)
            
            if "✅ تم الحذف بنجاح" in response:
                del users[game_id_to_remove]
                save_users()
                bot.reply_to(message, f"""🎉 *✅ تم الحذف بنجاح! ✅*

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
👤 *معلومات اللاعب المحذوف:*
├ **الاسم:** {name}
└ **الأيدي:** `{game_id_to_remove}`

📊 *تم تحرير مكان في قائمة الإضافات*
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

✨ *يمكنك الآن إضافة لاعب جديد!* ✨""", parse_mode="Markdown")
            else:
                bot.reply_to(message, f"""❌ *خطأ أثناء الحذف!*

👤 *الاسم:* {name}
📩 *الخطأ:* {response}

⚠️ *اللاعب ما زال في القائمة وسيتم المحاولة لاحقاً.*

🔧 *للإبلاغ عن مشكلة:* """, parse_mode="Markdown", disable_web_page_preview=True)
        else:
            bot.reply_to(message, """❌ *هذا الأيدي غير موجود!*

📌 *الأسباب المحتملة:*
1. الأيدي غير صحيح
2. اللاعب غير مضاف في البوت
3. انتهت مدة الإضافة

💡 *يمكنك التحقق من القائمة باستخدام أمر:* 
`/add <الأيدي>` للإضافة الجديدة""", parse_mode="Markdown")
    except Exception as e:
        print(f"[REMOVE_ERROR] {e}")
        bot.reply_to(message, """❌ *حدث خطأ أثناء الحذف!*

📌 *يرجى التأكد من:*
1. كتابة الأيدي بشكل صحيح
2. استخدام الأمر بالشكل الصحيح
3. الاتصال بالإنترنت

🔧 *للإبلاغ عن مشكلة:* [@fight_90](https://t.me/sargohht)""", parse_mode="Markdown", disable_web_page_preview=True)

@bot.message_handler(commands=['myadds'], chat_types=['group', 'supergroup'])
def my_adds_group(message):
    """عرض إحصائيات المستخدم في المجموعات مع نظام الرتب"""
    if not is_allowed_group(message):
        return
    
    user_tele_id = str(message.from_user.id)
    username = message.from_user.username or "بدون معرف"
    first_name = message.from_user.first_name or ""
    user_rank = get_user_rank(message)
    rank_info = rank_system.get_rank_info(user_rank)
    daily_limit = bot_settings.get_daily_limit_for_rank(user_rank)
    
    # حساب الوقت المتبقي حتى تجديد الإضافات
    now = time.time()
    next_reset = ((now // 86400) + 1) * 86400  # منتصف الليل القادم
    time_to_reset = format_duration(next_reset - now)
    
    if user_tele_id in users and isinstance(users[user_tele_id], dict):
        adds_today = users[user_tele_id].get("adds_today", 0)
        remaining = daily_limit - adds_today
        
        # حساب الإضافات الشهرية (تقريبية)
        monthly_adds = adds_today * 30  # تقدير تقريبي
        
        my_adds_message = f"""
📊 *📈 إحصائياتك الشخصية 📈*

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🎖️ *رتبتك:* {user_rank} {rank_info['emoji']}
👤 *معلومات المستخدم:*
├ **الاسم:** {first_name}
├ **المعرف:** @{username}
└ **الأيدي:** `{user_tele_id}`

🎯 *الإحصائيات اليومية:*
├ **الإضافات اليوم:** {adds_today}
├ **الحد اليومي:** {daily_limit}
└ **المتبقي لك:** {remaining}

⏳ *معلومات الوقت:*
├ **تتجدد الإضافات بعد:** {time_to_reset}
└ **الوقت الحالي:** {datetime.now().strftime("%H:%M:%S")}

📅 *تقديرات شهرية:*
├ **إضافات متوقعة هذا الشهر:** ~{monthly_adds}
└ **أيام الإضافة المتاحة:** 365 يوم/سنة

📈 *إحصائيات البوت:*
├ **إجمالي اللاعبين:** {get_total_users_count()}/{bot_settings.get('max_users')}
└ **حالة البوت:** 🟢 تعمل بنجاح
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

💎 *✨ ترقية رتبتك ✨*
للترقية إلى رتبة أعلى مع مميزات أكثر، تواصل مع:

✨ *استمتع بتجربة الإضافة المميزة!* ✨
        """
        
        bot.reply_to(message, my_adds_message, parse_mode="Markdown")
    else:
        if is_admin(message):
            admin_message = f"""
👑 *إحصائيات المسؤول*

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
👤 *معلومات المسؤول:*
├ **الاسم:** {first_name}
├ **المعرف:** @{username}
└ **الأيدي:** `{user_tele_id}`

🎯 *صلاحيات المسؤول:*
├ **كمية الإضافات:** ♾️ غير محدود
├ **المدة القصوى:** {format_duration(bot_settings.get('max_duration'))}
└ **التحكم الكامل:** ✅ مفعل

📊 *إحصائيات النظام:*
├ **إجمالي اللاعبين:** {get_total_users_count()}/{bot_settings.get('max_users')}
├ **المجموعات النشطة:** {len(group_activations)}
├ **حالة التوكن:** {'✅ نشط' if JWT_TOKEN else '❌ غير متوفر'}
└ **حالة البوت:** 🟢 تعمل بنجاح
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

✨ *أنت تملك جميع الصلاحيات!* ✨
            """
            bot.reply_to(message, admin_message, parse_mode="Markdown")
        else:
            new_user_message = f"""
🎉 *مرحباً بك في البوت!* 🎉

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🎖️ *رتبتك الحالية:* {user_rank} {rank_info['emoji']}
👤 *معلومات حسابك الجديد:*
├ **الاسم:** {first_name}
├ **المعرف:** @{username}
└ **الأيدي:** `{user_tele_id}`

🎯 *إحصائياتك اليومية:*
├ **عدد الإضافات اليوم:** 0
├ **الحد اليومي:** {daily_limit}
└ **المتبقي لك اليوم:** {daily_limit}

💡 *ماذا يمكنك أن تفعل؟*
• إضافة {daily_limit} لاعب يومياً
• اختيار المدة من 30 دقيقة إلى {format_duration(rank_info['max_duration'])}
• إضافة ما يصل إلى {daily_limit * 365} يوماً سنوياً
• متابعة المدة المتبقية لكل لاعب

📌 *للبدء في الإضافة:*
`/add 123456789 1d`
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

💎 *✨ ترقية رتبتك ✨*
للترقية إلى رتبة VIP أو ماسي مع مميزات أكثر، تواصل مع:

✨ *استمتع بتجربة الإضافة المميزة!* ✨
            """
            bot.reply_to(message, new_user_message, parse_mode="Markdown")

@bot.message_handler(commands=['status'], chat_types=['group', 'supergroup'])
def bot_status_group(message):
    """عرض حالة البوت في المجموعة مع نظام الرتب"""
    if not is_allowed_group(message):
        return
    
    current_count = get_total_users_count()
    user_rank = get_user_rank(message)
    rank_info = rank_system.get_rank_info(user_rank)
    
    status_message = f"""
📊 *🔍 حالة البوت الحالية 🔍*

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🎖️ *رتبتك:* {user_rank} {rank_info['emoji']}
🎮 *معلومات البوت:*
├ **اسم البوت:** {bot_settings.get('bot_name')}
├ **اللاعبين المضافين:** {current_count}/{bot_settings.get('max_users')}
├ **المساحة المتبقية:** {bot_settings.get('max_users') - current_count}
└ **حالة النظام:** {'🟢 تعمل بنجاح' if not maintenance_mode else '🔴 في الصيانة'}

⚡ *الحدود والإعدادات:*
├ **الحد اليومي لرتبتك:** {bot_settings.get_daily_limit_for_rank(user_rank)} إضافة/مستخدم
├ **المدة الافتراضية لرتبتك:** {format_duration(bot_settings.get_default_duration_for_rank(user_rank))}
├ **المدة القصوى لرتبتك:** {format_duration(rank_info['max_duration'])}
└ **التحديث التلقائي:** ✅ مفعل

⏰ *معلومات الوقت:*
├ **الوقت الحالي:** {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}
├ **التوقيت العالمي:** UTC
└ **تاريخ التفعيل:** {datetime.fromtimestamp(group_activations[str(message.chat.id)]).strftime("%Y-%m-%d") if str(message.chat.id) in group_activations else 'غير مفعل'}

📈 *إحصائيات المجموعة:*
├ **عدد الأعضاء:** {message.chat.member_count if hasattr(message.chat, 'member_count') else 'غير معروف'}
├ **تفعيل المجموعة:** {'✅ مفعل' if str(message.chat.id) in group_activations else '❌ غير مفعل'}
└ **مدة التفعيل:** {format_remaining_time(group_activations[str(message.chat.id)]) if str(message.chat.id) in group_activations else 'غير مفعل'}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

💡 *للحصول على المساعدة:* /help
✨ *{bot_settings.get('bot_name')} - الإضافة الأفضل!* ✨
    """
    
    bot.reply_to(message, status_message, parse_mode="Markdown")

@bot.message_handler(commands=['vipinfo'], chat_types=['group', 'supergroup'])
def vip_info_command(message):
    """معلومات عن حساب VIP"""
    if not is_allowed_group(message):
        return
    
    vip_info = rank_system.get_rank_info("VIP")
    
    vip_message = f"""
💎 *⭐ معلومات حساب VIP ⭐*

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🎖️ *مميزات حساب VIP:*
├ **الحد اليومي:** {vip_info['daily_limit']} إضافة
├ **المدة القصوى:** {format_duration(vip_info['max_duration'])}
├ **لون الرتبة:** {vip_info['color']}
└ **الأوامر الإضافية:** ✅ متاحة

📋 *الأوامر المتاحة:*
• جميع أوامر المستخدم العادي
• `/vipinfo` - عرض هذه المعلومات

💰 *فوائد الترقية إلى VIP:*
1. زيادة الحد اليومي من 2 إلى {vip_info['daily_limit']} إضافة
2. زيادة المدة القصوى إلى شهر كامل
3. دعم فني مميز
4. أولوية في الإضافات

🎯 *كيفية الترقية إلى VIP:*
للحصول على عرض VIP المميز

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

✨ *استمتع بتجربة VIP المميزة!* ✨
    """
    
    bot.reply_to(message, vip_message, parse_mode="Markdown")

@bot.message_handler(commands=['diamondinfo'], chat_types=['group', 'supergroup'])
def diamond_info_command(message):
    """معلومات عن حساب الماسي"""
    if not is_allowed_group(message):
        return
    
    diamond_info = rank_system.get_rank_info("ماسي")
    
    diamond_message = f"""
💎 *💎 معلومات حساب الماسي 💎*

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🎖️ *مميزات حساب الماسي:*
├ **الحد اليومي:** ♾️ غير محدود
├ **المدة القصوى:** {format_duration(diamond_info['max_duration'])}
├ **لون الرتبة:** {diamond_info['color']}
└ **الأوامر الإضافية:** ✅ متاحة

📋 *الأوامر المتاحة:*
• جميع أوامر VIP
• `/diamondinfo` - عرض هذه المعلومات
• `/check <id>` - التحقق من لاعب

💰 *فوائد الترقية إلى الماسي:*
1. إضافة غير محدودة يومياً
2. المدة القصوى سنة كاملة
3. دعم فني فوري
4. أولوية قصوى في الإضافات
5. صلاحيات إضافية

🎯 *كيفية الترقية إلى الماسي:*
للحصول على عرض الماسي الحصري

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

✨ *استمتع بتجربة الماسي الاستثنائية!* ✨
    """
    
    bot.reply_to(message, diamond_message, parse_mode="Markdown")

@bot.message_handler(commands=['check'], chat_types=['group', 'supergroup'])
def check_player_group(message):
    """التحقق من لاعب في المجموعات (للماسي فقط)"""
    if not is_allowed_group(message):
        return
    
    user_rank = get_user_rank(message)
    if user_rank not in ["ماسي", "مدير"]:
        bot.reply_to(message, "❌ *هذا الأمر متاح فقط لحسابات الماسي والمسؤولين!*\n\n💎 للترقية إلى رتبة الماسي، تواصل مع [@fight_90](@fight_90)", parse_mode="Markdown")
        return
    
    try:
        parts = message.text.split()
        if len(parts) != 2:
            bot.reply_to(message, "❌ *الاستخدام:* `/check <الأيدي>`\nمثال: `/check 123456789`", parse_mode="Markdown")
            return
        
        game_id = parts[1]
        
        if not game_id.isdigit():
            bot.reply_to(message, "❌ *خطأ:* الأيدي يجب أن يحتوي على أرقام فقط.")
            return
        
        name, region, level = get_player_info(game_id)
        
        if game_id in users:
            player_data = users[game_id]
            remaining = format_remaining_time(player_data["expiry"])
            status = "✅ مضاف في البوت"
            added_by = player_data.get('added_by_tele_username', 'غير معروف')
            added_date = player_data.get('added_date', 'غير معروف')
            duration = format_duration(player_data.get('duration_seconds', 0))
            added_by_rank = player_data.get('added_by_rank', 'غير معروف')
        else:
            remaining = "❌ غير مضاف"
            status = "❌ غير مضاف في البوت"
            added_by = "غير معروف"
            added_date = "غير معروف"
            duration = "غير معروف"
            added_by_rank = "غير معروف"
        
        check_message = f"""
🔍 *معلومات اللاعب الكاملة*

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🎖️ *رتبة المستخدم:* {user_rank}
👤 *المعلومات الأساسية:*
├ **الاسم:** {name}
├ **الأيدي:** `{game_id}`
├ **المنطقة:** {region}
└ **المستوى:** {level}

📊 *معلومات البوت:*
├ **حالة البوت:** {status}
├ **مدة الإضافة:** {duration}
├ **المدة المتبقية:** {remaining}
├ **المضيف:** @{added_by}
├ **رتبة المضيف:** {added_by_rank}
└ **تاريخ الإضافة:** {added_date}

🔗 *روابط سريعة:*
• للإضافة: `/add {game_id}`
• للحذف: `/remove {game_id}`
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
"""
        
        bot.reply_to(message, check_message, parse_mode="Markdown")
        
    except Exception as e:
        bot.reply_to(message, f"❌ حدث خطأ: {str(e)}")

# ============== أوامر المسؤول في الخاص مع نظام الرتب ==============

@bot.message_handler(commands=['start', 'help'], chat_types=['private'])
def handle_private_commands(message):
    """أوامر المسؤول في الخاص فقط"""
    if not is_admin(message):
        bot.reply_to(message, "🔒 *عذراً، هذا البوت مخصص للإدارة فقط!*\n\n📌 *للإستخدام يرجى الذهاب إلى إحدى المجموعات التي تحتوي على البوت.*\n\n📞 *المطور:* [@fight_90](https://t.me/sargohht)", parse_mode="Markdown", disable_web_page_preview=True)
        return
    
    user_id = message.from_user.id
    username = message.from_user.username or "بدون معرف"
    first_name = message.from_user.first_name or ""
    last_name = message.from_user.last_name or ""
    full_name = f"{first_name} {last_name}".strip()
    
    current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    help_text = f"""
👑 *🔧 لوحة تحكم المسؤول 🔧*
════════════════════════════════════

📋 *معلومات المسؤول:*
┌─────────────────────────────┐
│ 🆔 *الأيدي:* `{user_id}`      │
│ 👤 *المستخدم:* @{username}     │
│ 📛 *الاسم:* {full_name}       │
│ 🕐 *الوقت:* {current_time}    │
└─────────────────────────────┘

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🎮 *🔹 أوامر إدارة اللاعبين 🔹*
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

📥 *الإضافة المتقدمة:*
• `/add <id> <الوقت>` - إضافة مع تحديد الوقت
• `/add_user <id> <رتبة> <مدة>` - إضافة مستخدم برتبة

📤 *العرض والحذف:*
• `/list` - عرض جميع اللاعبين
• `/check <id>` - معلومات لاعب معين
• `/remove_all` - حذف جميع اللاعبين
• `/remove <id>` - حذف لاعب معين

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🎖️ *🔹 أوامر إدارة الرتب 🔹*
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

⚡ *تعيين الرتب:*
• `/setrank <user_id> <رتبة>` - تعيين رتبة لمستخدم
• `/getrank <user_id>` - عرض رتبة مستخدم
• `/ranks` - عرض جميع الرتب
• `/rankstats` - إحصائيات الرتب

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🏢 *🔹 أوامر إدارة المجموعات 🔹*
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

⚡ *التفعيل والإيقاف:*
• `/sargo <الأيام>` - تفعيل البوت في مجموعة
• `/stop` - إيقاف البوت في مجموعة
• `/leave_group <id>` - الخروج من مجموعة

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
⚙️ *🔹 أوامر إعدادات النظام 🔹*
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

🛠️ *الصيانة:*
• `/maintenance` - تفعيل وضع الصيانة
• `/unmaintenance` - إلغاء وضع الصيانة

🔧 *الإعدادات:*
• `/settings` - عرض إعدادات البوت
• `/setlimit <رتبة> <عدد>` - تغيير الحد اليومي للرتبة
• `/setduration <رتبة> <ثواني>` - تغيير المدة الافتراضية للرتبة
• `/setmaxusers <عدد>` - تغيير الحد الأقصى
• `/setbotname <اسم>` - تغيير اسم البوت

📈 *المعلومات:*
• `/stats` - إحصائيات البوت الكاملة
• `/update_token` - تحديث التوكن يدوياً
• `/broadcast <الرسالة>` - بث رسالة لجميع المجموعات

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🎯 *🔹 معلومات النظام 🔹*
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

📊 *إحصائيات حالية:*
• اللاعبين المضافين: {get_total_users_count()}/{bot_settings.get('max_users')}
• المجموعات النشطة: {len(group_activations)}
• حالة التوكن: {'✅ نشط' if JWT_TOKEN else '❌ غير متوفر'}
• وضع الصيانة: {'✅ مفعل' if maintenance_mode else '❌ غير مفعل'}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
💎 *✨ صلاحيات المسؤول الكاملة ✨*
════════════════════════════════════
    """
    bot.reply_to(message, help_text, parse_mode="Markdown", disable_web_page_preview=True)

@bot.message_handler(commands=['setrank'], chat_types=['private'])
def set_rank_command(message):
    """تعيين رتبة لمستخدم - للمسؤول فقط"""
    if not is_admin(message):
        return
    
    try:
        parts = message.text.split()
        if len(parts) != 3:
            bot.reply_to(message, "❌ *الاستخدام:* `/setrank <user_id> <رتبة>`\n\n📌 *الرتب المتاحة:* عادي، VIP، ماسي\n\n📝 *مثال:* `/setrank 123456789 VIP`", parse_mode="Markdown")
            return
        
        user_id = parts[1]
        rank_name = parts[2]
        
        # التحقق من صحة الرتبة
        if rank_name not in rank_system.RANKS:
            bot.reply_to(message, f"❌ *خطأ:* الرتبة '{rank_name}' غير موجودة!\n\n📌 *الرتب المتاحة:* عادي، VIP، ماسي")
            return
        
        # تعيين الرتبة
        if rank_system.set_user_rank(user_id, rank_name):
            rank_info = rank_system.get_rank_info(rank_name)
            bot.reply_to(message, f"""✅ *تم تعيين الرتبة بنجاح!*

📋 *معلومات الترقية:*
├ **المستخدم:** `{user_id}`
├ **الرتبة الجديدة:** {rank_name} {rank_info['emoji']}
├ **الحد اليومي:** {rank_info['daily_limit']}
├ **المدة القصوى:** {format_duration(rank_info['max_duration'])}
└ **الأوامر المتاحة:** {len(rank_info['commands'])} أمر

✨ *تمت ترقية المستخدم بنجاح!* ✨""", parse_mode="Markdown")
        else:
            bot.reply_to(message, "❌ *خطأ:* فشل تعيين الرتبة!")
            
    except Exception as e:
        bot.reply_to(message, f"❌ *حدث خطأ:* {str(e)}")

@bot.message_handler(commands=['getrank'], chat_types=['private'])
def get_rank_command(message):
    """عرض رتبة مستخدم - للمسؤول فقط"""
    if not is_admin(message):
        return
    
    try:
        parts = message.text.split()
        if len(parts) != 2:
            bot.reply_to(message, "❌ *الاستخدام:* `/getrank <user_id>`\n\n📝 *مثال:* `/getrank 123456789`", parse_mode="Markdown")
            return
        
        user_id = parts[1]
        rank_name = rank_system.get_user_rank(int(user_id) if user_id.isdigit() else user_id)
        rank_info = rank_system.get_rank_info(rank_name)
        
        bot.reply_to(message, f"""📋 *معلومات رتبة المستخدم:*

├ **المستخدم:** `{user_id}`
├ **الرتبة الحالية:** {rank_name} {rank_info['emoji']}
├ **الحد اليومي:** {rank_info['daily_limit']}
├ **المدة القصوى:** {format_duration(rank_info['max_duration'])}
└ **الأوامر المتاحة:** {len(rank_info['commands'])} أمر

📝 *وصف الرتبة:* {rank_info['description']}""", parse_mode="Markdown")
        
    except Exception as e:
        bot.reply_to(message, f"❌ *حدث خطأ:* {str(e)}")

@bot.message_handler(commands=['ranks'], chat_types=['private'])
def ranks_command(message):
    """عرض جميع الرتب - للمسؤول فقط"""
    if not is_admin(message):
        return
    
    ranks_info = rank_system.get_all_ranks()
    ranks_message = "📋 *🔹 جميع الرتب المتاحة 🔹*\n\n"
    
    for rank_name, rank_info in ranks_info.items():
        if rank_name != "مدير":  # لا نعرض رتبة المدير
            ranks_message += f"""🎖️ *{rank_name} {rank_info['emoji']}*
├ **الحد اليومي:** {rank_info['daily_limit']}
├ **المدة القصوى:** {format_duration(rank_info['max_duration'])}
├ **لون الرتبة:** {rank_info['color']}
└ **الأوامر:** {', '.join(rank_info['commands'])}
───────────────────
"""
    
    ranks_message += "\n💡 *لتعيين رتبة لمستخدم:* `/setrank <user_id> <رتبة>`"
    bot.reply_to(message, ranks_message, parse_mode="Markdown")

@bot.message_handler(commands=['rankstats'], chat_types=['private'])
def rank_stats_command(message):
    """إحصائيات الرتب - للمسؤول فقط"""
    if not is_admin(message):
        return
    
    try:
        # جمع إحصائيات الرتب
        rank_counts = {"عادي": 0, "VIP": 0, "ماسي": 0, "مدير": 0}
        
        # عد المستخدمين حسب الرتبة من ملف الرتب
        for user_id, rank_name in rank_system.user_ranks.items():
            if rank_name in rank_counts:
                rank_counts[rank_name] += 1
        
        # عد المسؤولين
        rank_counts["مدير"] = len(ADMIN_IDS)
        
        # عد المستخدمين العاديين (المتبقين)
        total_users = len(rank_system.user_ranks) + len(ADMIN_IDS)
        rank_counts["عادي"] = total_users - rank_counts["VIP"] - rank_counts["ماسي"] - rank_counts["مدير"]
        
        stats_message = f"""📊 *🔹 إحصائيات الرتب 🔹*

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📈 *توزيع المستخدمين حسب الرتب:*
"""
        
        total = sum(rank_counts.values())
        for rank_name, count in rank_counts.items():
            if rank_name != "مدير" or count > 0:
                percentage = (count / total * 100) if total > 0 else 0
                rank_info = rank_system.get_rank_info(rank_name)
                stats_message += f"├ **{rank_name} {rank_info['emoji']}:** {count} ({percentage:.1f}%)\n"
        
        stats_message += f"""└ **الإجمالي:** {total} مستخدم

📊 *إحصائيات الإضافة حسب الرتب:*
"""
        
        # حساب إحصائيات الإضافة حسب الرتب
        for rank_name in ["عادي", "VIP", "ماسي"]:
            rank_info = rank_system.get_rank_info(rank_name)
            stats_message += f"├ **{rank_name}:** {rank_info['daily_limit']} إضافة/يوم | {format_duration(rank_info['max_duration'])}\n"
        
        stats_message += f"""└ **مدير:** ♾️ إضافة | {format_duration(rank_system.get_rank_info('مدير')['max_duration'])}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

💡 *لإدارة الرتب:* `/ranks`
✨ *لتعيين رتبة:* `/setrank <user_id> <رتبة>`
"""
        
        bot.reply_to(message, stats_message, parse_mode="Markdown")
        
    except Exception as e:
        bot.reply_to(message, f"❌ *حدث خطأ:* {str(e)}")

@bot.message_handler(commands=['setlimit'], chat_types=['private'])
def set_limit_command(message):
    """تغيير الحد اليومي لرتبة معينة"""
    if not is_admin(message):
        return
    
    try:
        parts = message.text.split()
        if len(parts) != 3:
            bot.reply_to(message, "❌ *الاستخدام:* `/setlimit <رتبة> <عدد>`\n\n📌 *الرتب المتاحة:* normal, vip, diamond\n\n📝 *مثال:* `/setlimit vip 10`", parse_mode="Markdown")
            return
        
        rank_type = parts[1]
        new_limit = int(parts[2])
        
        if new_limit < 1 or new_limit > 999999:
            bot.reply_to(message, "❌ *خطأ:* الحد اليومي يجب أن يكون بين 1 و 999999")
            return
        
        if rank_type == "normal":
            bot_settings.set("daily_limit_normal", new_limit)
            rank_name = "عادي"
        elif rank_type == "vip":
            bot_settings.set("daily_limit_vip", new_limit)
            rank_name = "VIP"
        elif rank_type == "diamond":
            bot_settings.set("daily_limit_diamond", new_limit)
            rank_name = "ماسي"
        else:
            bot.reply_to(message, "❌ *خطأ:* نوع الرتبة غير صحيح!\n\n📌 *الرتب المتاحة:* normal, vip, diamond")
            return
        
        bot.reply_to(message, f"✅ *تم تغيير الحد اليومي لرتبة {rank_name} إلى {new_limit} إضافة لكل مستخدم*", parse_mode="Markdown")
        
    except ValueError:
        bot.reply_to(message, "❌ *خطأ:* الرقم غير صحيح")
    except Exception as e:
        bot.reply_to(message, f"❌ *حدث خطأ:* {e}")

@bot.message_handler(commands=['setduration'], chat_types=['private'])
def set_duration_command(message):
    """تغيير المدة الافتراضية لرتبة معينة"""
    if not is_admin(message):
        return
    
    try:
        parts = message.text.split()
        if len(parts) != 3:
            bot.reply_to(message, "❌ *الاستخدام:* `/setduration <رتبة> <ثواني>`\n\n📌 *الرتب المتاحة:* normal, vip, diamond\n\n📝 *مثال:* `/setduration normal 86400` (يوم)", parse_mode="Markdown")
            return
        
        rank_type = parts[1]
        new_duration = int(parts[2])
        
        if new_duration < 60 or new_duration > 31536000:
            bot.reply_to(message, "❌ *خطأ:* المدة يجب أن تكون بين 60 ثانية و 31536000 ثانية (سنة)")
            return
        
        if rank_type == "normal":
            bot_settings.set("default_duration_normal", new_duration)
            rank_name = "عادي"
        elif rank_type == "vip":
            bot_settings.set("default_duration_vip", new_duration)
            rank_name = "VIP"
        elif rank_type == "diamond":
            bot_settings.set("default_duration_diamond", new_duration)
            rank_name = "ماسي"
        else:
            bot.reply_to(message, "❌ *خطأ:* نوع الرتبة غير صحيح!\n\n📌 *الرتب المتاحة:* normal, vip, diamond")
            return
        
        formatted = format_duration(new_duration)
        bot.reply_to(message, f"✅ *تم تغيير المدة الافتراضية لرتبة {rank_name} إلى {formatted}*", parse_mode="Markdown")
        
    except ValueError:
        bot.reply_to(message, "❌ *خطأ:* الرقم غير صحيح")
    except Exception as e:
        bot.reply_to(message, f"❌ *حدث خطأ:* {e}")

# ============== بقية أوامر المسؤول ==============

@bot.message_handler(commands=['add_user'], chat_types=['private'])
def add_user_with_rank_command(message):
    """إضافة مستخدم برتبة محددة - للمسؤول فقط"""
    if not is_admin(message):
        return
    
    try:
        parts = message.text.split()
        if len(parts) != 4:
            bot.reply_to(message, "❌ *الاستخدام:* `/add_user <id> <رتبة> <مدة>`\n\n📝 *مثال:* `/add_user 123456789 vip 30d`", parse_mode="Markdown")
            return
        
        game_id = parts[1]
        rank_name = parts[2]
        time_str = parts[3]
        
        # التحقق من صحة الرتبة
        if rank_name not in rank_system.RANKS:
            bot.reply_to(message, f"❌ *خطأ:* الرتبة '{rank_name}' غير موجودة!\n\n📌 *الرتب المتاحة:* عادي، VIP، ماسي")
            return
        
        # حساب المدة
        time_duration = parse_time_duration(time_str, rank_name)
        
        # التحقق من الحد الأقصى
        current_count = get_total_users_count()
        if current_count >= bot_settings.get("max_users"):
            bot.reply_to(message, f"❌ *وصل البوت للحد الأقصى من الإضافات ({bot_settings.get('max_users')} حساب)!*")
            return
        
        # التحقق إذا كان اللاعب موجودًا
        if game_id in users:
            remaining = format_remaining_time(users[game_id]["expiry"])
            bot.reply_to(message, f"❌ *هذا اللاعب مضاف بالفعل!*\n⏳ المدة المتبقية: {remaining}")
            return
        
        # إضافة اللاعب
        name, region, level = get_player_info(game_id)
        
        users[game_id] = {
            "name": name,
            "expiry": time.time() + time_duration,
            "added_by_tele_id": str(message.from_user.id),
            "added_by_tele_username": message.from_user.username or "بدون معرف",
            "added_date": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "duration_seconds": time_duration,
            "added_by_rank": "مدير",
            "special_rank": rank_name
        }
        
        save_users()
        
        formatted_duration = format_duration(time_duration)
        rank_info = rank_system.get_rank_info(rank_name)
        
        success_message = f"""✅ *تمت الإضافة بنجاح!*

🎖️ *نوع الإضافة:* {rank_name} {rank_info['emoji']} (خاص)
👤 *الاسم:* {name}
🆔 *الأيدي:* `{game_id}`
⏳ *المدة:* {formatted_duration}
🌍 *المنطقة:* {region}
🎮 *المستوى:* {level}

📌 *تمت الإضافة بواسطة المسؤول برتبة خاصة*
"""
        bot.reply_to(message, success_message, parse_mode="Markdown")
        
    except Exception as e:
        bot.reply_to(message, f"❌ *حدث خطأ:* {str(e)}")

@bot.message_handler(commands=['stats'], chat_types=['private'])
def stats_command_private(message):
    """إحصائيات البوت مع نظام الرتب"""
    if not is_admin(message):
        return
    
    total_users = len(users)
    active_groups = len(group_activations)
    current_count = get_total_users_count()
    
    # إحصائيات الرتب
    rank_stats = {"عادي": 0, "VIP": 0, "ماسي": 0, "مدير": 0}
    for data in users.values():
        if isinstance(data, dict):
            rank = data.get("added_by_rank", "عادي")
            if rank in rank_stats:
                rank_stats[rank] += 1
    
    stats_message = f"""📈 *إحصائيات البوت الكاملة*

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
👥 *المستخدمين:*
├ **إجمالي المستخدمين:** {total_users}
├ **لاعبين مضافين:** {current_count}/{bot_settings.get('max_users')}
├ **المساحة المتبقية:** {bot_settings.get('max_users') - current_count}
└ **إضافات اليوم:** {sum([1 for d in users.values() if isinstance(d, dict) and d.get("added_date", "").startswith(datetime.now().strftime("%Y-%m-%d"))])}

🏢 *المجموعات:*
├ **المجموعات النشطة:** {active_groups}
└ **المجموعات منتهية:** {len([exp for exp in group_activations.values() if exp <= time.time()])}

🎖️ *إحصائيات الرتب:*
"""
    
    for rank_name, count in rank_stats.items():
        if count > 0:
            percentage = (count / current_count * 100) if current_count > 0 else 0
            rank_info = rank_system.get_rank_info(rank_name)
            stats_message += f"├ **{rank_name} {rank_info['emoji']}:** {count} ({percentage:.1f}%)\n"
    
    stats_message += f"""└ **المتوسط:** {format_duration(sum([d.get('duration_seconds', 0) for d in users.values() if isinstance(d, dict)]) // current_count if current_count > 0 else 0)}

⚡ *الأداء:*
├ **حالة التوكن:** {'✅ نشط' if JWT_TOKEN else '❌ غير متوفر'}
├ **وضع الصيانة:** {'✅ مفعل' if maintenance_mode else '❌ غير مفعل'}
└ **التحديث التلقائي:** ✅ نشط

⏰ *معلومات النظام:*
├ **الوقت الحالي:** {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}
├ **زمن التشغيل:** {format_duration(time.time() - start_time if 'start_time' in locals() else time.time())}
└ **حالة السيرفر:** 🟢 تعمل بنجاح
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
"""
    
    bot.reply_to(message, stats_message, parse_mode="Markdown")

# ============== بقية الأوامر (باقي الكود) ==============
# باقي الأوامر تبقى كما هي مع تعديلات بسيطة للتكيف مع نظام الرتب

@bot.message_handler(commands=['sargo'])
def activate_group(message):
    if not is_admin(message):
        bot.reply_to(message, "⚠️ هذا الأمر مخصص فقط لي المالك فقط ")
        return

    if message.chat.type == 'private':
        bot.reply_to(message, "❌ لا يمكن تفعيل البوت في الدردشة الخاصة، يرجى استخدام هذا الأمر في المجموعة.")
        return
    
    if maintenance_mode:
        bot.reply_to(message, "⚙️ البوت في وضع الصيانة حالياً.\nسوف يتم إعادته بعد الانتهاء من الصيانة.\nنعتذر على الازعاج.", parse_mode="Markdown")
        return
    
    try:
        parts = message.text.split()
        if len(parts) != 2:
            bot.reply_to(message, "❌ الاستخدام: `/sargo <عدد الأيام>`\nمثال: `/sargo 30`", parse_mode="Markdown")
            return

        days_str = parts[1]
        days = int(days_str)
        
        if days < 1 or days > 365:
            bot.reply_to(message, "❌ عدد الأيام يجب أن يكون بين 1 و 365 يوم")
            return
            
        chat_id = message.chat.id

        expiry_date = datetime.now() + timedelta(days=days)
        group_activations[str(chat_id)] = expiry_date.timestamp()
        save_groups()

        formatted_date = expiry_date.strftime("%Y-%m-%d %H:%M:%S UTC")
        bot.reply_to(message, f"""✅ *تم تفعيل البوت في الجروب بنجاح!*

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📋 *معلومات التفعيل:*
├ **المدة:** {days} يوم
├ **ينتهي في:** {formatted_date}
├ **المجموعة:** {message.chat.title}
└ **معرف المجموعة:** `{chat_id}`

📊 *إحصائيات المجموعات:*
├ **المجموعات المفعلة:** {len(group_activations)}
├ **المدة المتبقية:** {format_duration(days * 86400)}
└ **التفعيل حتى:** {days} يوم
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

💡 *يمكن للمستخدمين الآن استخدام البوت في هذه المجموعة!*""", parse_mode="Markdown")

    except ValueError:
        bot.reply_to(message, "❌ عدد الأيام يجب أن يكون رقماً.")
    except Exception as e:
        print(f"[SID_ERROR] {e}")
        bot.reply_to(message, "❌ حدث خطأ أثناء التفعيل.")

@bot.message_handler(func=lambda message: message.chat.type == 'private' and not is_admin(message))
def handle_private_non_admin(message):
    """الرد على المستخدمين العاديين في الخاص"""
    bot.reply_to(message, f"""
🔒 *عذراً، هذا البوت مخصص للإدارة فقط!*

📌 *للإستخدام يرجى:*
1. الذهاب إلى إحدى المجموعات التي تحتوي على البوت
2. استخدام الأوامر المتاحة هناك

🏢 *الأوامر المتاحة في المجموعات:*
• `/add <id>` - إضافة لاعب (حسب رتبتك)
• `/remove <id>` - إزالة لاعب
• `/myadds` - عرض إحصائياتك اليومية
• `/status` - حالة البوت الحالية
• `/help` - المساعدة الكاملة حسب رتبتك

للترقية إلى رتبة أعلى، تواصل مع المطور على :

Insta☞ @saifislem77

TikTok☞ ...

Telegram☞ @fight_90

""", parse_mode="Markdown", disable_web_page_preview=True)

# ============== بدء تشغيل البوت ==============
start_time = time.time()

print("""
╔══════════════════════════════════════════════════╗
║        🚀 بدء تشغيل البوت المتطور...           ║
╠══════════════════════════════════════════════════╣
║ 📌 إصدار البوت: 4.0.0 (نظام الرتب)             ║
║ 📅 تاريخ البناء: 2026                          ║
║ 👨‍💻 المطور: @fight_90                  ║
╠══════════════════════════════════════════════════╣
║ 🎖️ نظام الرتب الجديد:                          ║
║   • 👤 عادي - 24 ساعة / 2 إضافة يومياً         ║
║   • ⭐ VIP - 30 يوم / 5 إضافة يومياً           ║
║   • 💎 ماسي - سنة / غير محدود                 ║
║   • 👑 مدير - كامل الصلاحيات                   ║
╠══════════════════════════════════════════════════╣
║ 🎮 أوامر المجموعات حسب الرتبة:                 ║
║   • /add <id> <الوقت> - إضافة لاعب             ║
║   • /remove <id> - إزالة لاعب                   ║
║   • /myadds - إحصائيات المستخدم                ║
║   • /status - حالة البوت                        ║
║   • /help - المساعدة حسب الرتبة                ║
╠══════════════════════════════════════════════════╣
║ 🔧 أوامر المسؤول في الخاص:                     ║
║   • /setrank <id> <رتبة> - تعيين رتبة          ║
║   • /getrank <id> - عرض رتبة                   ║
║   • /ranks - عرض جميع الرتب                    ║
║   • /rankstats - إحصائيات الرتب                ║
║   • جميع الأوامر المتقدمة                      ║
╠══════════════════════════════════════════════════╣
║ 🎯 الميزات الجديدة:                            ║
║   • نظام الرتب المتكامل                        ║
║   • حدود ومميزات حسب الرتبة                    ║
║   • تصميم مبهر ومتطور                         ║
║   • إحصائيات مفصلة للرتب                      ║
║   • إدارة سهلة للمسؤولين                       ║
╠══════════════════════════════════════════════════╣
║     Telegram : @fight_90                 ║
║ 🎨 تصميم: @fight_90                    ║
╚══════════════════════════════════════════════════╝
""")

print(f"📊 معلومات النظام:")
print(f"   • اللاعبين الحاليين: {get_total_users_count()}/{bot_settings.get('max_users')}")
print(f"   • المجموعات المفعلة: {len(group_activations)}")
print(f"   • نظام الرتب: ✅ مفعل ({len(rank_system.user_ranks)} مستخدم برتب خاصة)")
print(f"   • الحدود اليومية: عادي({bot_settings.get('daily_limit_normal')}) | VIP({bot_settings.get('daily_limit_vip')}) | ماسي({bot_settings.get('daily_limit_diamond')})")

bot.polling(none_stop=True, allowed_updates=['message', 'callback_query', 'inline_query'])